-- --------------------------------------------------------
-- 호스트:                          127.0.0.1
-- 서버 버전:                        5.6.26 - MySQL Community Server (GPL)
-- 서버 OS:                        Win32
-- HeidiSQL 버전:                  9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- 테이블 my_test_db.bas_affiliate 구조 내보내기
DROP TABLE IF EXISTS `bas_affiliate`;
CREATE TABLE IF NOT EXISTS `bas_affiliate` (
  `SEQ` decimal(10,0) unsigned NOT NULL COMMENT '일련번호',
  `AFFILIATE_NM` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT '계열사명',
  PRIMARY KEY (`SEQ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='기초자료_계열사 ';

-- 테이블 데이터 my_test_db.bas_affiliate:~3 rows (대략적) 내보내기
/*!40000 ALTER TABLE `bas_affiliate` DISABLE KEYS */;
INSERT INTO `bas_affiliate` (`SEQ`, `AFFILIATE_NM`) VALUES
	(0, '없음'),
	(1, 'CGV'),
	(2, 'MEGA'),
	(3, 'LOTTE');
/*!40000 ALTER TABLE `bas_affiliate` ENABLE KEYS */;


-- 테이블 my_test_db.bas_contact 구조 내보내기
DROP TABLE IF EXISTS `bas_contact`;
CREATE TABLE IF NOT EXISTS `bas_contact` (
  `CODE` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '연락처구분코드',
  `CONTACT_NM` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT '연락처구분명',
  `order_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='기초자료_연락처구분';

-- 테이블 데이터 my_test_db.bas_contact:~3 rows (대략적) 내보내기
/*!40000 ALTER TABLE `bas_contact` DISABLE KEYS */;
INSERT INTO `bas_contact` (`CODE`, `CONTACT_NM`, `order_no`) VALUES
	('P', '부금담당자', 2),
	('S', '스코어담당자', 1),
	('T', '극장관리담당자', 3);
/*!40000 ALTER TABLE `bas_contact` ENABLE KEYS */;


-- 테이블 my_test_db.bas_distributor 구조 내보내기
DROP TABLE IF EXISTS `bas_distributor`;
CREATE TABLE IF NOT EXISTS `bas_distributor` (
  `SEQ` decimal(10,0) unsigned NOT NULL DEFAULT '0' COMMENT '일련번호',
  `DISTRIBUTOR_NM` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT '배급사명',
  PRIMARY KEY (`SEQ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='기초자료_배급사';

-- 테이블 데이터 my_test_db.bas_distributor:~5 rows (대략적) 내보내기
/*!40000 ALTER TABLE `bas_distributor` DISABLE KEYS */;
INSERT INTO `bas_distributor` (`SEQ`, `DISTRIBUTOR_NM`) VALUES
	(1, 'Sony Pictures'),
	(2, 'Showbox'),
	(3, 'Lotte Entertanment'),
	(4, 'CINE Guru'),
	(5, '이수 C&E');
/*!40000 ALTER TABLE `bas_distributor` ENABLE KEYS */;


-- 테이블 my_test_db.bas_genre 구조 내보내기
DROP TABLE IF EXISTS `bas_genre`;
CREATE TABLE IF NOT EXISTS `bas_genre` (
  `SEQ` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '일련번호',
  `GENRE_NM` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '장르명',
  PRIMARY KEY (`SEQ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='기초자료_장르';

-- 테이블 데이터 my_test_db.bas_genre:~8 rows (대략적) 내보내기
/*!40000 ALTER TABLE `bas_genre` DISABLE KEYS */;
INSERT INTO `bas_genre` (`SEQ`, `GENRE_NM`) VALUES
	(1, 'SF'),
	(2, '애니메이션'),
	(3, '액션'),
	(4, '드라마'),
	(5, '코미디'),
	(6, '호러'),
	(7, '판타지'),
	(8, '스릴러');
/*!40000 ALTER TABLE `bas_genre` ENABLE KEYS */;


-- 테이블 my_test_db.bas_grade 구조 내보내기
DROP TABLE IF EXISTS `bas_grade`;
CREATE TABLE IF NOT EXISTS `bas_grade` (
  `SEQ` decimal(10,0) unsigned NOT NULL DEFAULT '0' COMMENT '일련번호',
  `GRADE_NM` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT '관람등급명',
  PRIMARY KEY (`SEQ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='기초자료_등급';

-- 테이블 데이터 my_test_db.bas_grade:~4 rows (대략적) 내보내기
/*!40000 ALTER TABLE `bas_grade` DISABLE KEYS */;
INSERT INTO `bas_grade` (`SEQ`, `GRADE_NM`) VALUES
	(1, '전체 관람가'),
	(2, '12세 관람가'),
	(3, '15세 관람가'),
	(4, '청소년 관람불가');
/*!40000 ALTER TABLE `bas_grade` ENABLE KEYS */;


-- 테이블 my_test_db.bas_inning 구조 내보내기
DROP TABLE IF EXISTS `bas_inning`;
CREATE TABLE IF NOT EXISTS `bas_inning` (
  `SEQ` decimal(10,0) unsigned NOT NULL DEFAULT '0' COMMENT '일련번호',
  `INNING_NM` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT '회차명',
  PRIMARY KEY (`SEQ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='기초자료_회차';

-- 테이블 데이터 my_test_db.bas_inning:~16 rows (대략적) 내보내기
/*!40000 ALTER TABLE `bas_inning` DISABLE KEYS */;
INSERT INTO `bas_inning` (`SEQ`, `INNING_NM`) VALUES
	(0, '특회'),
	(1, '1회'),
	(2, '2회'),
	(3, '3회'),
	(4, '4회'),
	(5, '5회'),
	(6, '6회'),
	(7, '7회'),
	(8, '8회'),
	(9, '9회'),
	(10, '10회'),
	(11, '11회'),
	(12, '12회'),
	(13, '13회'),
	(14, '14회'),
	(15, '15회');
/*!40000 ALTER TABLE `bas_inning` ENABLE KEYS */;


-- 테이블 my_test_db.bas_isdirect 구조 내보내기
DROP TABLE IF EXISTS `bas_isdirect`;
CREATE TABLE IF NOT EXISTS `bas_isdirect` (
  `CODE` varchar(1) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Y:직영/N:위탁',
  `DIRECT_NM` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT '직영/위탁',
  PRIMARY KEY (`CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='기초자료_직영위탁구분';

-- 테이블 데이터 my_test_db.bas_isdirect:~2 rows (대략적) 내보내기
/*!40000 ALTER TABLE `bas_isdirect` DISABLE KEYS */;
INSERT INTO `bas_isdirect` (`CODE`, `DIRECT_NM`) VALUES
	('', '없음'),
	('N', '위탁'),
	('Y', '직영');
/*!40000 ALTER TABLE `bas_isdirect` ENABLE KEYS */;


-- 테이블 my_test_db.bas_korabd_gbn 구조 내보내기
DROP TABLE IF EXISTS `bas_korabd_gbn`;
CREATE TABLE IF NOT EXISTS `bas_korabd_gbn` (
  `CODE` enum('K','A') COLLATE utf8_unicode_ci NOT NULL COMMENT 'Korea:방화/Abroad:외화',
  `GBN_NM` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT '구분명',
  PRIMARY KEY (`CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='기초자료_배급사구분';

-- 테이블 데이터 my_test_db.bas_korabd_gbn:~2 rows (대략적) 내보내기
/*!40000 ALTER TABLE `bas_korabd_gbn` DISABLE KEYS */;
INSERT INTO `bas_korabd_gbn` (`CODE`, `GBN_NM`) VALUES
	('K', '방화'),
	('A', '외화');
/*!40000 ALTER TABLE `bas_korabd_gbn` ENABLE KEYS */;


-- 테이블 my_test_db.bas_location 구조 내보내기
DROP TABLE IF EXISTS `bas_location`;
CREATE TABLE IF NOT EXISTS `bas_location` (
  `SEQ` decimal(10,0) unsigned NOT NULL DEFAULT '0' COMMENT '일련법호',
  `LOCATION_NM` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT '지역명',
  `PARENT_SEQ` decimal(10,0) NOT NULL COMMENT '상위지역일련번호',
  PRIMARY KEY (`SEQ`),
  KEY `IDX_PARENT_SEQ` (`PARENT_SEQ`),
  CONSTRAINT `FK_BAS_LOCATION_BAS_LOCATION` FOREIGN KEY (`PARENT_SEQ`) REFERENCES `bas_location` (`SEQ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='기초자료_지역분류';

-- 테이블 데이터 my_test_db.bas_location:~24 rows (대략적) 내보내기
/*!40000 ALTER TABLE `bas_location` DISABLE KEYS */;
INSERT INTO `bas_location` (`SEQ`, `LOCATION_NM`, `PARENT_SEQ`) VALUES
	(0, '無', 0),
	(100, '서울', 0),
	(101, '서울시', 100),
	(200, '경강', 0),
	(201, '인천시', 200),
	(202, '경기도', 200),
	(203, '강원도', 200),
	(300, '충청', 0),
	(301, '대전시', 300),
	(302, '충청남도', 300),
	(303, '충청북도', 300),
	(304, '세종시', 300),
	(400, '경남', 0),
	(401, '부산시', 400),
	(402, '울산시', 400),
	(403, '경상남도', 400),
	(500, '경북', 0),
	(501, '대구시', 500),
	(502, '경상북도', 500),
	(600, '호남', 0),
	(601, '광주시', 600),
	(602, '전라남도', 600),
	(603, '전라북도', 600),
	(604, '제주도', 600);
/*!40000 ALTER TABLE `bas_location` ENABLE KEYS */;


-- 테이블 my_test_db.bas_playprint1 구조 내보내기
DROP TABLE IF EXISTS `bas_playprint1`;
CREATE TABLE IF NOT EXISTS `bas_playprint1` (
  `SEQ` decimal(10,0) unsigned NOT NULL DEFAULT '0' COMMENT '일련번호',
  `PLAY_PRINT_NM` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT '상영프린트명',
  PRIMARY KEY (`SEQ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='기초자료_상영프린트1';

-- 테이블 데이터 my_test_db.bas_playprint1:~6 rows (대략적) 내보내기
/*!40000 ALTER TABLE `bas_playprint1` DISABLE KEYS */;
INSERT INTO `bas_playprint1` (`SEQ`, `PLAY_PRINT_NM`) VALUES
	(1, '필름'),
	(2, '2D'),
	(3, '3D'),
	(4, '4D'),
	(5, 'IMAX'),
	(6, 'Atmos');
/*!40000 ALTER TABLE `bas_playprint1` ENABLE KEYS */;


-- 테이블 my_test_db.bas_playprint2 구조 내보내기
DROP TABLE IF EXISTS `bas_playprint2`;
CREATE TABLE IF NOT EXISTS `bas_playprint2` (
  `SEQ` decimal(10,0) unsigned NOT NULL DEFAULT '0' COMMENT '일련번호',
  `PLAY_PRINT_NM` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT '상영프린트명',
  PRIMARY KEY (`SEQ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='기초자료_상영프린트2';

-- 테이블 데이터 my_test_db.bas_playprint2:~2 rows (대략적) 내보내기
/*!40000 ALTER TABLE `bas_playprint2` DISABLE KEYS */;
INSERT INTO `bas_playprint2` (`SEQ`, `PLAY_PRINT_NM`) VALUES
	(1, '자막'),
	(2, '더빙');
/*!40000 ALTER TABLE `bas_playprint2` ENABLE KEYS */;


-- 테이블 my_test_db.bas_premium_rate 구조 내보내기
DROP TABLE IF EXISTS `bas_premium_rate`;
CREATE TABLE IF NOT EXISTS `bas_premium_rate` (
  `SEQ` decimal(10,0) unsigned NOT NULL DEFAULT '0' COMMENT '일련번호',
  `KORABD_GBN_CODE` enum('K','A') COLLATE utf8_unicode_ci NOT NULL COMMENT 'K:방화/A:외화',
  `LOCATION_SEQ` decimal(10,0) unsigned NOT NULL COMMENT '지역 일련번호',
  `AFFILIATE_SEQ` decimal(10,0) unsigned DEFAULT NULL COMMENT '계열사 일련번호',
  `ISDIRECT_CODE` varchar(1) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Y:직영/N:위탁',
  `UNAFFILIATE_SEQ` decimal(10,0) unsigned DEFAULT NULL COMMENT '비계열사 일련번호',
  `PREMIUM_RATE` decimal(4,2) unsigned NOT NULL COMMENT '부율',
  PRIMARY KEY (`SEQ`),
  KEY `FK_BAS_PREMIUM_RATE_BAS_KORABD_GBN` (`KORABD_GBN_CODE`),
  KEY `FK_BAS_PREMIUM_RATE_BAS_LOCATION` (`LOCATION_SEQ`),
  KEY `FK_BAS_PREMIUM_RATE_BAS_AFFILIATE` (`AFFILIATE_SEQ`),
  KEY `FK_BAS_PREMIUM_RATE_BAS_ISDIRECT` (`ISDIRECT_CODE`),
  KEY `FK_BAS_PREMIUM_RATE_BAS_UNAFFILIATE` (`UNAFFILIATE_SEQ`),
  CONSTRAINT `FK_BAS_PREMIUM_RATE_BAS_AFFILIATE` FOREIGN KEY (`AFFILIATE_SEQ`) REFERENCES `bas_affiliate` (`SEQ`),
  CONSTRAINT `FK_BAS_PREMIUM_RATE_BAS_ISDIRECT` FOREIGN KEY (`ISDIRECT_CODE`) REFERENCES `bas_isdirect` (`CODE`),
  CONSTRAINT `FK_BAS_PREMIUM_RATE_BAS_KORABD_GBN` FOREIGN KEY (`KORABD_GBN_CODE`) REFERENCES `bas_korabd_gbn` (`CODE`),
  CONSTRAINT `FK_BAS_PREMIUM_RATE_BAS_LOCATION` FOREIGN KEY (`LOCATION_SEQ`) REFERENCES `bas_location` (`SEQ`),
  CONSTRAINT `FK_BAS_PREMIUM_RATE_BAS_UNAFFILIATE` FOREIGN KEY (`UNAFFILIATE_SEQ`) REFERENCES `bas_unaffiliate` (`SEQ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='기초_부율 정보';

-- 테이블 데이터 my_test_db.bas_premium_rate:~306 rows (대략적) 내보내기
/*!40000 ALTER TABLE `bas_premium_rate` DISABLE KEYS */;
INSERT INTO `bas_premium_rate` (`SEQ`, `KORABD_GBN_CODE`, `LOCATION_SEQ`, `AFFILIATE_SEQ`, `ISDIRECT_CODE`, `UNAFFILIATE_SEQ`, `PREMIUM_RATE`) VALUES
	(1, 'A', 101, 0, '', 1, 50.00),
	(2, 'A', 101, 0, '', 2, 50.00),
	(3, 'A', 101, 0, '', 3, 50.00),
	(4, 'A', 101, 1, 'Y', 0, 50.00),
	(5, 'A', 101, 1, 'N', 0, 50.00),
	(6, 'A', 101, 2, 'Y', 0, 50.00),
	(7, 'A', 101, 2, 'N', 0, 50.00),
	(8, 'A', 101, 3, 'Y', 0, 50.00),
	(9, 'A', 101, 3, 'N', 0, 50.00),
	(10, 'A', 201, 0, '', 1, 50.00),
	(11, 'A', 201, 0, '', 2, 50.00),
	(12, 'A', 201, 0, '', 3, 50.00),
	(13, 'A', 201, 1, 'Y', 0, 50.00),
	(14, 'A', 201, 1, 'N', 0, 50.00),
	(15, 'A', 201, 2, 'Y', 0, 50.00),
	(16, 'A', 201, 2, 'N', 0, 50.00),
	(17, 'A', 201, 3, 'Y', 0, 50.00),
	(18, 'A', 201, 3, 'N', 0, 50.00),
	(19, 'A', 202, 0, '', 1, 50.00),
	(20, 'A', 202, 0, '', 2, 50.00),
	(21, 'A', 202, 0, '', 3, 50.00),
	(22, 'A', 202, 1, 'Y', 0, 50.00),
	(23, 'A', 202, 1, 'N', 0, 50.00),
	(24, 'A', 202, 2, 'Y', 0, 50.00),
	(25, 'A', 202, 2, 'N', 0, 50.00),
	(26, 'A', 202, 3, 'Y', 0, 50.00),
	(27, 'A', 202, 3, 'N', 0, 50.00),
	(28, 'A', 203, 0, '', 1, 50.00),
	(29, 'A', 203, 0, '', 2, 50.00),
	(30, 'A', 203, 0, '', 3, 50.00),
	(31, 'A', 203, 1, 'Y', 0, 50.00),
	(32, 'A', 203, 1, 'N', 0, 50.00),
	(33, 'A', 203, 2, 'Y', 0, 50.00),
	(34, 'A', 203, 2, 'N', 0, 50.00),
	(35, 'A', 203, 3, 'Y', 0, 50.00),
	(36, 'A', 203, 3, 'N', 0, 50.00),
	(37, 'A', 301, 0, '', 1, 50.00),
	(38, 'A', 301, 0, '', 2, 50.00),
	(39, 'A', 301, 0, '', 3, 50.00),
	(40, 'A', 301, 1, 'Y', 0, 50.00),
	(41, 'A', 301, 1, 'N', 0, 50.00),
	(42, 'A', 301, 2, 'Y', 0, 50.00),
	(43, 'A', 301, 2, 'N', 0, 50.00),
	(44, 'A', 301, 3, 'Y', 0, 50.00),
	(45, 'A', 301, 3, 'N', 0, 50.00),
	(46, 'A', 302, 0, '', 1, 50.00),
	(47, 'A', 302, 0, '', 2, 50.00),
	(48, 'A', 302, 0, '', 3, 50.00),
	(49, 'A', 302, 1, 'Y', 0, 50.00),
	(50, 'A', 302, 1, 'N', 0, 50.00),
	(51, 'A', 302, 2, 'Y', 0, 50.00),
	(52, 'A', 302, 2, 'N', 0, 50.00),
	(53, 'A', 302, 3, 'Y', 0, 50.00),
	(54, 'A', 302, 3, 'N', 0, 50.00),
	(55, 'A', 303, 0, '', 1, 50.00),
	(56, 'A', 303, 0, '', 2, 50.00),
	(57, 'A', 303, 0, '', 3, 50.00),
	(58, 'A', 303, 1, 'Y', 0, 50.00),
	(59, 'A', 303, 1, 'N', 0, 50.00),
	(60, 'A', 303, 2, 'Y', 0, 50.00),
	(61, 'A', 303, 2, 'N', 0, 50.00),
	(62, 'A', 303, 3, 'Y', 0, 50.00),
	(63, 'A', 303, 3, 'N', 0, 50.00),
	(64, 'A', 304, 0, '', 1, 50.00),
	(65, 'A', 304, 0, '', 2, 50.00),
	(66, 'A', 304, 0, '', 3, 50.00),
	(67, 'A', 304, 1, 'Y', 0, 50.00),
	(68, 'A', 304, 1, 'N', 0, 50.00),
	(69, 'A', 304, 2, 'Y', 0, 50.00),
	(70, 'A', 304, 2, 'N', 0, 50.00),
	(71, 'A', 304, 3, 'Y', 0, 50.00),
	(72, 'A', 304, 3, 'N', 0, 50.00),
	(73, 'A', 401, 0, '', 1, 50.00),
	(74, 'A', 401, 0, '', 2, 50.00),
	(75, 'A', 401, 0, '', 3, 50.00),
	(76, 'A', 401, 1, 'Y', 0, 50.00),
	(77, 'A', 401, 1, 'N', 0, 50.00),
	(78, 'A', 401, 2, 'Y', 0, 50.00),
	(79, 'A', 401, 2, 'N', 0, 50.00),
	(80, 'A', 401, 3, 'Y', 0, 50.00),
	(81, 'A', 401, 3, 'N', 0, 50.00),
	(82, 'A', 402, 0, '', 1, 50.00),
	(83, 'A', 402, 0, '', 2, 50.00),
	(84, 'A', 402, 0, '', 3, 50.00),
	(85, 'A', 402, 1, 'Y', 0, 50.00),
	(86, 'A', 402, 1, 'N', 0, 50.00),
	(87, 'A', 402, 2, 'Y', 0, 50.00),
	(88, 'A', 402, 2, 'N', 0, 50.00),
	(89, 'A', 402, 3, 'Y', 0, 50.00),
	(90, 'A', 402, 3, 'N', 0, 50.00),
	(91, 'A', 403, 0, '', 1, 50.00),
	(92, 'A', 403, 0, '', 2, 50.00),
	(93, 'A', 403, 0, '', 3, 50.00),
	(94, 'A', 403, 1, 'Y', 0, 50.00),
	(95, 'A', 403, 1, 'N', 0, 50.00),
	(96, 'A', 403, 2, 'Y', 0, 50.00),
	(97, 'A', 403, 2, 'N', 0, 50.00),
	(98, 'A', 403, 3, 'Y', 0, 50.00),
	(99, 'A', 403, 3, 'N', 0, 50.00),
	(100, 'A', 501, 0, '', 1, 50.00),
	(101, 'A', 501, 0, '', 2, 50.00),
	(102, 'A', 501, 0, '', 3, 50.00),
	(103, 'A', 501, 1, 'Y', 0, 50.00),
	(104, 'A', 501, 1, 'N', 0, 50.00),
	(105, 'A', 501, 2, 'Y', 0, 50.00),
	(106, 'A', 501, 2, 'N', 0, 50.00),
	(107, 'A', 501, 3, 'Y', 0, 50.00),
	(108, 'A', 501, 3, 'N', 0, 50.00),
	(109, 'A', 502, 0, '', 1, 50.00),
	(110, 'A', 502, 0, '', 2, 50.00),
	(111, 'A', 502, 0, '', 3, 50.00),
	(112, 'A', 502, 1, 'Y', 0, 50.00),
	(113, 'A', 502, 1, 'N', 0, 50.00),
	(114, 'A', 502, 2, 'Y', 0, 50.00),
	(115, 'A', 502, 2, 'N', 0, 50.00),
	(116, 'A', 502, 3, 'Y', 0, 50.00),
	(117, 'A', 502, 3, 'N', 0, 50.00),
	(118, 'A', 601, 0, '', 1, 50.00),
	(119, 'A', 601, 0, '', 2, 50.00),
	(120, 'A', 601, 0, '', 3, 50.00),
	(121, 'A', 601, 1, 'Y', 0, 50.00),
	(122, 'A', 601, 1, 'N', 0, 50.00),
	(123, 'A', 601, 2, 'Y', 0, 50.00),
	(124, 'A', 601, 2, 'N', 0, 50.00),
	(125, 'A', 601, 3, 'Y', 0, 50.00),
	(126, 'A', 601, 3, 'N', 0, 50.00),
	(127, 'A', 602, 0, '', 1, 50.00),
	(128, 'A', 602, 0, '', 2, 50.00),
	(129, 'A', 602, 0, '', 3, 50.00),
	(130, 'A', 602, 1, 'Y', 0, 50.00),
	(131, 'A', 602, 1, 'N', 0, 50.00),
	(132, 'A', 602, 2, 'Y', 0, 50.00),
	(133, 'A', 602, 2, 'N', 0, 50.00),
	(134, 'A', 602, 3, 'Y', 0, 50.00),
	(135, 'A', 602, 3, 'N', 0, 50.00),
	(136, 'A', 603, 0, '', 1, 50.00),
	(137, 'A', 603, 0, '', 2, 50.00),
	(138, 'A', 603, 0, '', 3, 50.00),
	(139, 'A', 603, 1, 'Y', 0, 50.00),
	(140, 'A', 603, 1, 'N', 0, 50.00),
	(141, 'A', 603, 2, 'Y', 0, 50.00),
	(142, 'A', 603, 2, 'N', 0, 50.00),
	(143, 'A', 603, 3, 'Y', 0, 50.00),
	(144, 'A', 603, 3, 'N', 0, 50.00),
	(145, 'A', 604, 0, '', 1, 50.00),
	(146, 'A', 604, 0, '', 2, 50.00),
	(147, 'A', 604, 0, '', 3, 50.00),
	(148, 'A', 604, 1, 'Y', 0, 50.00),
	(149, 'A', 604, 1, 'N', 0, 50.00),
	(150, 'A', 604, 2, 'Y', 0, 50.00),
	(151, 'A', 604, 2, 'N', 0, 50.00),
	(152, 'A', 604, 3, 'Y', 0, 50.00),
	(153, 'A', 604, 3, 'N', 0, 50.00),
	(154, 'K', 101, 0, '', 1, 50.00),
	(155, 'K', 101, 0, '', 2, 50.00),
	(156, 'K', 101, 0, '', 3, 50.00),
	(157, 'K', 101, 1, 'Y', 0, 50.00),
	(158, 'K', 101, 1, 'N', 0, 50.00),
	(159, 'K', 101, 2, 'Y', 0, 50.00),
	(160, 'K', 101, 2, 'N', 0, 50.00),
	(161, 'K', 101, 3, 'Y', 0, 50.00),
	(162, 'K', 101, 3, 'N', 0, 50.00),
	(163, 'K', 201, 0, '', 1, 50.00),
	(164, 'K', 201, 0, '', 2, 50.00),
	(165, 'K', 201, 0, '', 3, 50.00),
	(166, 'K', 201, 1, 'Y', 0, 50.00),
	(167, 'K', 201, 1, 'N', 0, 50.00),
	(168, 'K', 201, 2, 'Y', 0, 50.00),
	(169, 'K', 201, 2, 'N', 0, 50.00),
	(170, 'K', 201, 3, 'Y', 0, 50.00),
	(171, 'K', 201, 3, 'N', 0, 50.00),
	(172, 'K', 202, 0, '', 1, 50.00),
	(173, 'K', 202, 0, '', 2, 50.00),
	(174, 'K', 202, 0, '', 3, 50.00),
	(175, 'K', 202, 1, 'Y', 0, 50.00),
	(176, 'K', 202, 1, 'N', 0, 50.00),
	(177, 'K', 202, 2, 'Y', 0, 50.00),
	(178, 'K', 202, 2, 'N', 0, 50.00),
	(179, 'K', 202, 3, 'Y', 0, 50.00),
	(180, 'K', 202, 3, 'N', 0, 50.00),
	(181, 'K', 203, 0, '', 1, 50.00),
	(182, 'K', 203, 0, '', 2, 50.00),
	(183, 'K', 203, 0, '', 3, 50.00),
	(184, 'K', 203, 1, 'Y', 0, 50.00),
	(185, 'K', 203, 1, 'N', 0, 50.00),
	(186, 'K', 203, 2, 'Y', 0, 50.00),
	(187, 'K', 203, 2, 'N', 0, 50.00),
	(188, 'K', 203, 3, 'Y', 0, 50.00),
	(189, 'K', 203, 3, 'N', 0, 50.00),
	(190, 'K', 301, 0, '', 1, 50.00),
	(191, 'K', 301, 0, '', 2, 50.00),
	(192, 'K', 301, 0, '', 3, 50.00),
	(193, 'K', 301, 1, 'Y', 0, 50.00),
	(194, 'K', 301, 1, 'N', 0, 50.00),
	(195, 'K', 301, 2, 'Y', 0, 50.00),
	(196, 'K', 301, 2, 'N', 0, 50.00),
	(197, 'K', 301, 3, 'Y', 0, 50.00),
	(198, 'K', 301, 3, 'N', 0, 50.00),
	(199, 'K', 302, 0, '', 1, 50.00),
	(200, 'K', 302, 0, '', 2, 50.00),
	(201, 'K', 302, 0, '', 3, 50.00),
	(202, 'K', 302, 1, 'Y', 0, 50.00),
	(203, 'K', 302, 1, 'N', 0, 50.00),
	(204, 'K', 302, 2, 'Y', 0, 50.00),
	(205, 'K', 302, 2, 'N', 0, 50.00),
	(206, 'K', 302, 3, 'Y', 0, 50.00),
	(207, 'K', 302, 3, 'N', 0, 50.00),
	(208, 'K', 303, 0, '', 1, 50.00),
	(209, 'K', 303, 0, '', 2, 50.00),
	(210, 'K', 303, 0, '', 3, 50.00),
	(211, 'K', 303, 1, 'Y', 0, 50.00),
	(212, 'K', 303, 1, 'N', 0, 50.00),
	(213, 'K', 303, 2, 'Y', 0, 50.00),
	(214, 'K', 303, 2, 'N', 0, 50.00),
	(215, 'K', 303, 3, 'Y', 0, 50.00),
	(216, 'K', 303, 3, 'N', 0, 50.00),
	(217, 'K', 304, 0, '', 1, 50.00),
	(218, 'K', 304, 0, '', 2, 50.00),
	(219, 'K', 304, 0, '', 3, 50.00),
	(220, 'K', 304, 1, 'Y', 0, 50.00),
	(221, 'K', 304, 1, 'N', 0, 50.00),
	(222, 'K', 304, 2, 'Y', 0, 50.00),
	(223, 'K', 304, 2, 'N', 0, 50.00),
	(224, 'K', 304, 3, 'Y', 0, 50.00),
	(225, 'K', 304, 3, 'N', 0, 50.00),
	(226, 'K', 401, 0, '', 1, 50.00),
	(227, 'K', 401, 0, '', 2, 50.00),
	(228, 'K', 401, 0, '', 3, 50.00),
	(229, 'K', 401, 1, 'Y', 0, 50.00),
	(230, 'K', 401, 1, 'N', 0, 50.00),
	(231, 'K', 401, 2, 'Y', 0, 50.00),
	(232, 'K', 401, 2, 'N', 0, 50.00),
	(233, 'K', 401, 3, 'Y', 0, 50.00),
	(234, 'K', 401, 3, 'N', 0, 50.00),
	(235, 'K', 402, 0, '', 1, 50.00),
	(236, 'K', 402, 0, '', 2, 50.00),
	(237, 'K', 402, 0, '', 3, 50.00),
	(238, 'K', 402, 1, 'Y', 0, 50.00),
	(239, 'K', 402, 1, 'N', 0, 50.00),
	(240, 'K', 402, 2, 'Y', 0, 50.00),
	(241, 'K', 402, 2, 'N', 0, 50.00),
	(242, 'K', 402, 3, 'Y', 0, 50.00),
	(243, 'K', 402, 3, 'N', 0, 50.00),
	(244, 'K', 403, 0, '', 1, 50.00),
	(245, 'K', 403, 0, '', 2, 50.00),
	(246, 'K', 403, 0, '', 3, 50.00),
	(247, 'K', 403, 1, 'Y', 0, 50.00),
	(248, 'K', 403, 1, 'N', 0, 50.00),
	(249, 'K', 403, 2, 'Y', 0, 50.00),
	(250, 'K', 403, 2, 'N', 0, 50.00),
	(251, 'K', 403, 3, 'Y', 0, 50.00),
	(252, 'K', 403, 3, 'N', 0, 50.00),
	(253, 'K', 501, 0, '', 1, 50.00),
	(254, 'K', 501, 0, '', 2, 50.00),
	(255, 'K', 501, 0, '', 3, 50.00),
	(256, 'K', 501, 1, 'Y', 0, 50.00),
	(257, 'K', 501, 1, 'N', 0, 50.00),
	(258, 'K', 501, 2, 'Y', 0, 50.00),
	(259, 'K', 501, 2, 'N', 0, 50.00),
	(260, 'K', 501, 3, 'Y', 0, 50.00),
	(261, 'K', 501, 3, 'N', 0, 50.00),
	(262, 'K', 502, 0, '', 1, 50.00),
	(263, 'K', 502, 0, '', 2, 50.00),
	(264, 'K', 502, 0, '', 3, 50.00),
	(265, 'K', 502, 1, 'Y', 0, 50.00),
	(266, 'K', 502, 1, 'N', 0, 50.00),
	(267, 'K', 502, 2, 'Y', 0, 50.00),
	(268, 'K', 502, 2, 'N', 0, 50.00),
	(269, 'K', 502, 3, 'Y', 0, 50.00),
	(270, 'K', 502, 3, 'N', 0, 50.00),
	(271, 'K', 601, 0, '', 1, 50.00),
	(272, 'K', 601, 0, '', 2, 50.00),
	(273, 'K', 601, 0, '', 3, 50.00),
	(274, 'K', 601, 1, 'Y', 0, 50.00),
	(275, 'K', 601, 1, 'N', 0, 50.00),
	(276, 'K', 601, 2, 'Y', 0, 50.00),
	(277, 'K', 601, 2, 'N', 0, 50.00),
	(278, 'K', 601, 3, 'Y', 0, 50.00),
	(279, 'K', 601, 3, 'N', 0, 50.00),
	(280, 'K', 602, 0, '', 1, 50.00),
	(281, 'K', 602, 0, '', 2, 50.00),
	(282, 'K', 602, 0, '', 3, 50.00),
	(283, 'K', 602, 1, 'Y', 0, 50.00),
	(284, 'K', 602, 1, 'N', 0, 50.00),
	(285, 'K', 602, 2, 'Y', 0, 50.00),
	(286, 'K', 602, 2, 'N', 0, 50.00),
	(287, 'K', 602, 3, 'Y', 0, 50.00),
	(288, 'K', 602, 3, 'N', 0, 50.00),
	(289, 'K', 603, 0, '', 1, 50.00),
	(290, 'K', 603, 0, '', 2, 50.00),
	(291, 'K', 603, 0, '', 3, 50.00),
	(292, 'K', 603, 1, 'Y', 0, 50.00),
	(293, 'K', 603, 1, 'N', 0, 50.00),
	(294, 'K', 603, 2, 'Y', 0, 50.00),
	(295, 'K', 603, 2, 'N', 0, 50.00),
	(296, 'K', 603, 3, 'Y', 0, 50.00),
	(297, 'K', 603, 3, 'N', 0, 50.00),
	(298, 'K', 604, 0, '', 1, 50.00),
	(299, 'K', 604, 0, '', 2, 50.00),
	(300, 'K', 604, 0, '', 3, 50.00),
	(301, 'K', 604, 1, 'Y', 0, 50.00),
	(302, 'K', 604, 1, 'N', 0, 50.00),
	(303, 'K', 604, 2, 'Y', 0, 50.00),
	(304, 'K', 604, 2, 'N', 0, 50.00),
	(305, 'K', 604, 3, 'Y', 0, 50.00),
	(306, 'K', 604, 3, 'N', 0, 50.00);
/*!40000 ALTER TABLE `bas_premium_rate` ENABLE KEYS */;


-- 테이블 my_test_db.bas_spcial_seat 구조 내보내기
DROP TABLE IF EXISTS `bas_spcial_seat`;
CREATE TABLE IF NOT EXISTS `bas_spcial_seat` (
  `SEQ` decimal(10,0) unsigned NOT NULL DEFAULT '0' COMMENT '일련번호',
  `SPCIAL_SEAT_NM` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT '특별좌석명',
  PRIMARY KEY (`SEQ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='기초자료_특별좌석';

-- 테이블 데이터 my_test_db.bas_spcial_seat:~3 rows (대략적) 내보내기
/*!40000 ALTER TABLE `bas_spcial_seat` DISABLE KEYS */;
INSERT INTO `bas_spcial_seat` (`SEQ`, `SPCIAL_SEAT_NM`) VALUES
	(0, '직접입력'),
	(1, 'SWEETBOX'),
	(2, '장애인');
/*!40000 ALTER TABLE `bas_spcial_seat` ENABLE KEYS */;


-- 테이블 my_test_db.bas_unaffiliate 구조 내보내기
DROP TABLE IF EXISTS `bas_unaffiliate`;
CREATE TABLE IF NOT EXISTS `bas_unaffiliate` (
  `SEQ` decimal(10,0) unsigned NOT NULL COMMENT '일련번호',
  `UNAFFILIATE_NM` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT '비계열명',
  PRIMARY KEY (`SEQ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='기초자료_비계열';

-- 테이블 데이터 my_test_db.bas_unaffiliate:~3 rows (대략적) 내보내기
/*!40000 ALTER TABLE `bas_unaffiliate` DISABLE KEYS */;
INSERT INTO `bas_unaffiliate` (`SEQ`, `UNAFFILIATE_NM`) VALUES
	(0, '없음'),
	(1, '일반극장'),
	(2, '자동차극장'),
	(3, '예술극장');
/*!40000 ALTER TABLE `bas_unaffiliate` ENABLE KEYS */;


-- 테이블 my_test_db.bas_unitprice 구조 내보내기
DROP TABLE IF EXISTS `bas_unitprice`;
CREATE TABLE IF NOT EXISTS `bas_unitprice` (
  `SEQ` decimal(10,0) unsigned NOT NULL DEFAULT '0' COMMENT '일련번호',
  `UNIT_PRICE` decimal(10,0) NOT NULL COMMENT '단가',
  `DEL_FLAG` enum('Y','N') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N' COMMENT '삭제여부',
  PRIMARY KEY (`SEQ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='기초자료_단가';

-- 테이블 데이터 my_test_db.bas_unitprice:~12 rows (대략적) 내보내기
/*!40000 ALTER TABLE `bas_unitprice` DISABLE KEYS */;
INSERT INTO `bas_unitprice` (`SEQ`, `UNIT_PRICE`, `DEL_FLAG`) VALUES
	(1, 1000, ''),
	(2, 2000, ''),
	(3, 3000, ''),
	(4, 4000, ''),
	(5, 5000, ''),
	(6, 6000, ''),
	(7, 7000, ''),
	(8, 8000, ''),
	(9, 9000, ''),
	(10, 10000, ''),
	(11, 11000, ''),
	(12, 12000, '');
/*!40000 ALTER TABLE `bas_unitprice` ENABLE KEYS */;


-- 테이블 my_test_db.bas_user_group 구조 내보내기
DROP TABLE IF EXISTS `bas_user_group`;
CREATE TABLE IF NOT EXISTS `bas_user_group` (
  `SEQ` decimal(10,0) unsigned NOT NULL COMMENT '일련번호',
  `USER_GROUP_NM` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT '사용자그룹명',
  PRIMARY KEY (`SEQ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='기초자료_사용자그룹';

-- 테이블 데이터 my_test_db.bas_user_group:~2 rows (대략적) 내보내기
/*!40000 ALTER TABLE `bas_user_group` DISABLE KEYS */;
INSERT INTO `bas_user_group` (`SEQ`, `USER_GROUP_NM`) VALUES
	(0, '없음'),
	(1, '글로벌'),
	(2, '전주');
/*!40000 ALTER TABLE `bas_user_group` ENABLE KEYS */;


-- 테이블 my_test_db.cfg_sequence 구조 내보내기
DROP TABLE IF EXISTS `cfg_sequence`;
CREATE TABLE IF NOT EXISTS `cfg_sequence` (
  `ADMIN` decimal(10,0) unsigned NOT NULL COMMENT '관리자일련번호',
  `THEATER` decimal(4,0) unsigned NOT NULL COMMENT '극장일련번호',
  `FILM` decimal(7,0) unsigned NOT NULL COMMENT '영화일련번호',
  `PLAY` decimal(10,0) unsigned NOT NULL COMMENT '상영일련번호'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='환경_일련번호';

-- 테이블 데이터 my_test_db.cfg_sequence:~0 rows (대략적) 내보내기
/*!40000 ALTER TABLE `cfg_sequence` DISABLE KEYS */;
INSERT INTO `cfg_sequence` (`ADMIN`, `THEATER`, `FILM`, `PLAY`) VALUES
	(0, 53, 51, 5);
/*!40000 ALTER TABLE `cfg_sequence` ENABLE KEYS */;


-- 테이블 my_test_db.tmp_log 구조 내보내기
DROP TABLE IF EXISTS `tmp_log`;
CREATE TABLE IF NOT EXISTS `tmp_log` (
  `seq` int(10) unsigned NOT NULL,
  `log_datetime` datetime NOT NULL,
  `log_text` text COLLATE utf8_unicode_ci COMMENT '로그내용',
  PRIMARY KEY (`seq`),
  KEY `idx_datetime` (`log_datetime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='디버깅용 로그저장 테이블';

-- 테이블 데이터 my_test_db.tmp_log:~1 rows (대략적) 내보내기
/*!40000 ALTER TABLE `tmp_log` DISABLE KEYS */;
INSERT INTO `tmp_log` (`seq`, `log_datetime`, `log_text`) VALUES
	(0, '2017-01-02 08:56:56', '1분단위 로그 삭제 2017-01-02 08:56:56');
/*!40000 ALTER TABLE `tmp_log` ENABLE KEYS */;


-- 테이블 my_test_db.usr_admin 구조 내보내기
DROP TABLE IF EXISTS `usr_admin`;
CREATE TABLE IF NOT EXISTS `usr_admin` (
  `SEQ` decimal(10,0) unsigned NOT NULL DEFAULT '0' COMMENT '일련번호',
  `ADMIN_NM` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT '관리자명',
  PRIMARY KEY (`SEQ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='사용자_관리자 정보';

-- 테이블 데이터 my_test_db.usr_admin:~0 rows (대략적) 내보내기
/*!40000 ALTER TABLE `usr_admin` DISABLE KEYS */;
/*!40000 ALTER TABLE `usr_admin` ENABLE KEYS */;


-- 테이블 my_test_db.usr_login 구조 내보내기
DROP TABLE IF EXISTS `usr_login`;
CREATE TABLE IF NOT EXISTS `usr_login` (
  `ID` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '아이디',
  `PW` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT '비밀번호',
  `ADMIN_SEQ` decimal(10,0) NOT NULL COMMENT '일련번호',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='사용자_로그인 정보';

-- 테이블 데이터 my_test_db.usr_login:~0 rows (대략적) 내보내기
/*!40000 ALTER TABLE `usr_login` DISABLE KEYS */;
/*!40000 ALTER TABLE `usr_login` ENABLE KEYS */;


-- 테이블 my_test_db.wrk_contact 구조 내보내기
DROP TABLE IF EXISTS `wrk_contact`;
CREATE TABLE IF NOT EXISTS `wrk_contact` (
  `SEQ` decimal(10,0) unsigned NOT NULL COMMENT '연락처일련번호',
  `THEATER_CODE` varchar(6) COLLATE utf8_unicode_ci NOT NULL COMMENT '극장코드',
  `GBN_CODE` varchar(1) COLLATE utf8_unicode_ci NOT NULL COMMENT '연락처구분코드(S:스코어,P:부금,T:극장)',
  `NAME` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT '이름',
  `TEL` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT '전화번호',
  `HP` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT '휴대폰번호',
  `FAX` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT '팩스번호',
  `MAIL` varchar(30) COLLATE utf8_unicode_ci NOT NULL COMMENT '이메일',
  PRIMARY KEY (`SEQ`),
  KEY `FK_WRK_CONTACT_WRK_THEATER` (`THEATER_CODE`),
  KEY `FK_WRK_CONTACT_BAS_CONTACT` (`GBN_CODE`),
  CONSTRAINT `FK_WRK_CONTACT_BAS_CONTACT` FOREIGN KEY (`GBN_CODE`) REFERENCES `bas_contact` (`CODE`),
  CONSTRAINT `FK_WRK_CONTACT_WRK_THEATER` FOREIGN KEY (`THEATER_CODE`) REFERENCES `wrk_theater` (`CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='작업_연락처 정보';

-- 테이블 데이터 my_test_db.wrk_contact:~6 rows (대략적) 내보내기
/*!40000 ALTER TABLE `wrk_contact` DISABLE KEYS */;
INSERT INTO `wrk_contact` (`SEQ`, `THEATER_CODE`, `GBN_CODE`, `NAME`, `TEL`, `HP`, `FAX`, `MAIL`) VALUES
	(1, 'TH0001', 'S', '홍길동', '000-000', '213231', '233', 'ㄴㄴㄹ'),
	(2, 'TH0001', 'P', '김길동', '000-000', '213231', '233', 'ㄴㄴㄹ'),
	(3, 'TH0001', 'T', '이길동', '000-000', '213231', '233', 'ㄴㄴㄹ'),
	(4, 'TH0001', 'S', 's길동', '4234-234', '435', '', ''),
	(5, 'TH0001', 'P', 'p길동', '4324', '34', '', ''),
	(6, 'TH0001', 'T', 't길동', '234', '324', '', '');
/*!40000 ALTER TABLE `wrk_contact` ENABLE KEYS */;


-- 테이블 my_test_db.wrk_film 구조 내보내기
DROP TABLE IF EXISTS `wrk_film`;
CREATE TABLE IF NOT EXISTS `wrk_film` (
  `CODE` varchar(8) COLLATE utf8_unicode_ci NOT NULL COMMENT '영화코드(M0000001)',
  `DISTRIBUTOR` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT '배급사 영화코드',
  `FILM_NM` varchar(40) COLLATE utf8_unicode_ci NOT NULL COMMENT '대표영화명',
  `GRADE` decimal(10,0) DEFAULT NULL COMMENT '상영등급',
  `FIRST_PLAY_DT` date DEFAULT NULL COMMENT '최초상영일',
  `OPEN_DT` date DEFAULT NULL COMMENT '개봉일',
  `CLOSE_DT` date DEFAULT NULL COMMENT '종영일',
  `REOPEM_DT` date DEFAULT NULL COMMENT '재개봉일',
  `RECLOSE_DT` date DEFAULT NULL COMMENT '재종영일',
  `POSTER_YN` enum('Y','N') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N' COMMENT '포스터사용 유무',
  `IMAGES_NO` int(11) DEFAULT NULL COMMENT '이미지 첨부파일번호',
  `KORABD` enum('K,','A') COLLATE utf8_unicode_ci NOT NULL COMMENT '(K:방화,A:외화)',
  `DEL_FLAG` enum('Y','N') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N' COMMENT '삭제여부(Y:삭제,N:미삭제)',
  PRIMARY KEY (`CODE`),
  KEY `FK_WRK_FILM_BAS_GRADE` (`GRADE`),
  KEY `FK_WRK_FILM_BAS_KORABD_GBN` (`KORABD`),
  CONSTRAINT `FK_WRK_FILM_BAS_GRADE` FOREIGN KEY (`GRADE`) REFERENCES `bas_grade` (`SEQ`),
  CONSTRAINT `FK_WRK_FILM_BAS_KORABD_GBN` FOREIGN KEY (`KORABD`) REFERENCES `bas_korabd_gbn` (`CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='작업_영화 정보';

-- 테이블 데이터 my_test_db.wrk_film:~0 rows (대략적) 내보내기
/*!40000 ALTER TABLE `wrk_film` DISABLE KEYS */;
INSERT INTO `wrk_film` (`CODE`, `DISTRIBUTOR`, `FILM_NM`, `GRADE`, `FIRST_PLAY_DT`, `OPEN_DT`, `CLOSE_DT`, `REOPEM_DT`, `RECLOSE_DT`, `POSTER_YN`, `IMAGES_NO`, `KORABD`, `DEL_FLAG`) VALUES
	('M0000002', '221', '', 3, NULL, NULL, NULL, NULL, NULL, 'N', NULL, 'K,', 'Y');
/*!40000 ALTER TABLE `wrk_film` ENABLE KEYS */;


-- 테이블 my_test_db.wrk_film_distributor 구조 내보내기
DROP TABLE IF EXISTS `wrk_film_distributor`;
CREATE TABLE IF NOT EXISTS `wrk_film_distributor` (
  `FILM_CODE` varchar(8) COLLATE utf8_unicode_ci NOT NULL COMMENT '영화코드(M0000001)',
  `DISTRIBUTOR_SEQ` decimal(10,0) NOT NULL COMMENT '배급사일련번호',
  PRIMARY KEY (`FILM_CODE`,`DISTRIBUTOR_SEQ`),
  KEY `FK_WRK_FILM_DISTRIBUTOR_BAS_DISTRIBUTOR` (`DISTRIBUTOR_SEQ`),
  CONSTRAINT `FK_WRK_FILM_DISTRIBUTOR_BAS_DISTRIBUTOR` FOREIGN KEY (`DISTRIBUTOR_SEQ`) REFERENCES `bas_distributor` (`SEQ`),
  CONSTRAINT `FK_WRK_FILM_DISTRIBUTOR_WRK_FILM` FOREIGN KEY (`FILM_CODE`) REFERENCES `wrk_film` (`CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='작업_영화의 배급사 정보';

-- 테이블 데이터 my_test_db.wrk_film_distributor:~0 rows (대략적) 내보내기
/*!40000 ALTER TABLE `wrk_film_distributor` DISABLE KEYS */;
/*!40000 ALTER TABLE `wrk_film_distributor` ENABLE KEYS */;


-- 테이블 my_test_db.wrk_genre 구조 내보내기
DROP TABLE IF EXISTS `wrk_genre`;
CREATE TABLE IF NOT EXISTS `wrk_genre` (
  `FILM_CODE` varchar(6) COLLATE utf8_unicode_ci NOT NULL COMMENT '영화코드(M0000001)',
  `GENRE_SEQ` decimal(10,0) NOT NULL COMMENT '장르 일련번호',
  PRIMARY KEY (`FILM_CODE`,`GENRE_SEQ`),
  KEY `FK_WRK_GENRE_BAS_GENRE` (`GENRE_SEQ`),
  CONSTRAINT `FK_WRK_GENRE_BAS_GENRE` FOREIGN KEY (`GENRE_SEQ`) REFERENCES `bas_genre` (`SEQ`),
  CONSTRAINT `FK_WRK_GENRE_WRK_FILM` FOREIGN KEY (`FILM_CODE`) REFERENCES `wrk_film` (`CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='작업_장르 정보';

-- 테이블 데이터 my_test_db.wrk_genre:~0 rows (대략적) 내보내기
/*!40000 ALTER TABLE `wrk_genre` DISABLE KEYS */;
/*!40000 ALTER TABLE `wrk_genre` ENABLE KEYS */;


-- 테이블 my_test_db.wrk_images 구조 내보내기
DROP TABLE IF EXISTS `wrk_images`;
CREATE TABLE IF NOT EXISTS `wrk_images` (
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '자동증가',
  `IMAGE` mediumblob NOT NULL COMMENT '이미지',
  `TITLE` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT '파일명',
  `WIDTH` smallint(6) NOT NULL COMMENT '넓이',
  `HEIGHT` smallint(6) NOT NULL COMMENT '높이',
  `FILESIZE` int(11) NOT NULL COMMENT '파일크기',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='작업_이미지 첨부 파일\r\n(http://whitesal.com/article/article_view.php?no=3172&mode=3)';

-- 테이블 데이터 my_test_db.wrk_images:~0 rows (대략적) 내보내기
/*!40000 ALTER TABLE `wrk_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `wrk_images` ENABLE KEYS */;


-- 테이블 my_test_db.wrk_playprint 구조 내보내기
DROP TABLE IF EXISTS `wrk_playprint`;
CREATE TABLE IF NOT EXISTS `wrk_playprint` (
  `FILM_CODE` varchar(8) COLLATE utf8_unicode_ci NOT NULL COMMENT '영화코드(M0000001)',
  `PLAYPRINT1_SEQ` decimal(10,0) unsigned NOT NULL COMMENT '프린트1',
  `PLAYPRINT2_SEQ` decimal(10,0) unsigned NOT NULL COMMENT '프린트2',
  `MEMO` text COLLATE utf8_unicode_ci COMMENT '메모',
  PRIMARY KEY (`FILM_CODE`,`PLAYPRINT1_SEQ`,`PLAYPRINT2_SEQ`),
  KEY `FK_WRK_PLAYPRINT_BAS_PLAYPRINT1` (`PLAYPRINT1_SEQ`),
  KEY `FK_WRK_PLAYPRINT_BAS_PLAYPRINT2` (`PLAYPRINT2_SEQ`),
  CONSTRAINT `FK_WRK_PLAYPRINT_BAS_PLAYPRINT1` FOREIGN KEY (`PLAYPRINT1_SEQ`) REFERENCES `bas_playprint1` (`SEQ`),
  CONSTRAINT `FK_WRK_PLAYPRINT_BAS_PLAYPRINT2` FOREIGN KEY (`PLAYPRINT2_SEQ`) REFERENCES `bas_playprint2` (`SEQ`),
  CONSTRAINT `FK_WRK_PLAYPRINT_WRK_FILM` FOREIGN KEY (`FILM_CODE`) REFERENCES `wrk_film` (`CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='작업_영화프린트 정보';

-- 테이블 데이터 my_test_db.wrk_playprint:~2 rows (대략적) 내보내기
/*!40000 ALTER TABLE `wrk_playprint` DISABLE KEYS */;
INSERT INTO `wrk_playprint` (`FILM_CODE`, `PLAYPRINT1_SEQ`, `PLAYPRINT2_SEQ`, `MEMO`) VALUES
	('M0000002', 1, 1, 'fsfsdfsf'),
	('M0000002', 2, 1, 'SFSADF');
/*!40000 ALTER TABLE `wrk_playprint` ENABLE KEYS */;


-- 테이블 my_test_db.wrk_play_detail 구조 내보내기
DROP TABLE IF EXISTS `wrk_play_detail`;
CREATE TABLE IF NOT EXISTS `wrk_play_detail` (
  `SEQ` decimal(10,0) unsigned NOT NULL DEFAULT '0' COMMENT '일련번호',
  `PLAY_MAST_SEQ` decimal(10,0) unsigned NOT NULL COMMENT '상영MAST 일련번호',
  `UNITPRICE` decimal(10,0) unsigned NOT NULL COMMENT '단가',
  `INNING` decimal(10,0) unsigned NOT NULL COMMENT '회차',
  `SCORE` decimal(10,0) unsigned NOT NULL COMMENT '스코어',
  PRIMARY KEY (`SEQ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='작업_상영DETAIL 정보';

-- 테이블 데이터 my_test_db.wrk_play_detail:~0 rows (대략적) 내보내기
/*!40000 ALTER TABLE `wrk_play_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `wrk_play_detail` ENABLE KEYS */;


-- 테이블 my_test_db.wrk_play_mast 구조 내보내기
DROP TABLE IF EXISTS `wrk_play_mast`;
CREATE TABLE IF NOT EXISTS `wrk_play_mast` (
  `SEQ` decimal(10,0) unsigned NOT NULL DEFAULT '0' COMMENT '일련번호',
  `THEATER_CODE` varchar(6) COLLATE utf8_unicode_ci NOT NULL COMMENT '극장코드(TH0001)',
  `SHOWROOM_SEQ` decimal(10,0) NOT NULL COMMENT '상영관 일련번호',
  `FILM_CODE` varchar(6) COLLATE utf8_unicode_ci NOT NULL COMMENT '영화코드(M0000001)',
  `PRINT1_SEQ` decimal(10,0) unsigned NOT NULL COMMENT '프린트1 일련번호',
  `PRINT2_SEQ` decimal(10,0) unsigned NOT NULL COMMENT '프린트2 일련번호',
  `MEMO` text COLLATE utf8_unicode_ci COMMENT '비고',
  `CONFIRM` enum('Y','N') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N' COMMENT '확인여부',
  PRIMARY KEY (`SEQ`),
  KEY `IDX_THEATER_ROOM` (`THEATER_CODE`,`SHOWROOM_SEQ`),
  KEY `IDX_FILM_PRINT` (`FILM_CODE`,`PRINT1_SEQ`,`PRINT2_SEQ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='작업_상영 MASTER 정보';

-- 테이블 데이터 my_test_db.wrk_play_mast:~0 rows (대략적) 내보내기
/*!40000 ALTER TABLE `wrk_play_mast` DISABLE KEYS */;
/*!40000 ALTER TABLE `wrk_play_mast` ENABLE KEYS */;


-- 테이블 my_test_db.wrk_showroom 구조 내보내기
DROP TABLE IF EXISTS `wrk_showroom`;
CREATE TABLE IF NOT EXISTS `wrk_showroom` (
  `SEQ` decimal(10,0) unsigned NOT NULL DEFAULT '0' COMMENT '일련번호',
  `THEATER_CODE` varchar(6) COLLATE utf8_unicode_ci NOT NULL COMMENT '극장코드(TH0001)',
  `ROOM_NM` varchar(2) COLLATE utf8_unicode_ci NOT NULL COMMENT '상영관명',
  `ROOM_ALIAS` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '상영관별칭',
  `ART_ROOM` enum('Y','N') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N' COMMENT '예술관여부',
  `SEAT` decimal(10,0) NOT NULL COMMENT '좌석수',
  PRIMARY KEY (`SEQ`),
  KEY `FK_WRK_SHOWROOM_WRK_THEATER` (`THEATER_CODE`),
  CONSTRAINT `FK_WRK_SHOWROOM_WRK_THEATER` FOREIGN KEY (`THEATER_CODE`) REFERENCES `wrk_theater` (`CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='작업_상영관 정보';

-- 테이블 데이터 my_test_db.wrk_showroom:~3 rows (대략적) 내보내기
/*!40000 ALTER TABLE `wrk_showroom` DISABLE KEYS */;
INSERT INTO `wrk_showroom` (`SEQ`, `THEATER_CODE`, `ROOM_NM`, `ROOM_ALIAS`, `ART_ROOM`, `SEAT`) VALUES
	(1, 'TH0001', '1', '제일관', 'N', 100),
	(2, 'TH0001', '2', 'ㄴㅇ러ㅏ니', 'N', 100),
	(3, 'TH0001', '3', 'ㅇㄹ', 'N', 100);
/*!40000 ALTER TABLE `wrk_showroom` ENABLE KEYS */;


-- 테이블 my_test_db.wrk_spcial_seat 구조 내보내기
DROP TABLE IF EXISTS `wrk_spcial_seat`;
CREATE TABLE IF NOT EXISTS `wrk_spcial_seat` (
  `SEQ` decimal(10,0) unsigned NOT NULL DEFAULT '0' COMMENT '일련번호',
  `THEATER_CODE` varchar(6) COLLATE utf8_unicode_ci NOT NULL COMMENT '극장코드(TH0001)',
  `SHOWROOM_SEQ` decimal(10,0) NOT NULL COMMENT '상영관 일련번호',
  `SPCIAL_SEAT_SEQ` decimal(10,0) NOT NULL COMMENT '특별좌석 일련번호',
  `SPCIAL_SEAT_NM` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT '특별좌석명',
  `SPCIAL_SEAT_NUM` decimal(10,0) NOT NULL COMMENT '특별좌석수',
  PRIMARY KEY (`SEQ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='작업_특별좌석수 정보';

-- 테이블 데이터 my_test_db.wrk_spcial_seat:~0 rows (대략적) 내보내기
/*!40000 ALTER TABLE `wrk_spcial_seat` DISABLE KEYS */;
/*!40000 ALTER TABLE `wrk_spcial_seat` ENABLE KEYS */;


-- 테이블 my_test_db.wrk_theater 구조 내보내기
DROP TABLE IF EXISTS `wrk_theater`;
CREATE TABLE IF NOT EXISTS `wrk_theater` (
  `CODE` varchar(6) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '극장코드(TH0001)',
  `LOC1` decimal(10,0) NOT NULL COMMENT '지역1',
  `LOC2` decimal(10,0) NOT NULL COMMENT '지역2',
  `AFFILIATE_SEQ` decimal(10,0) DEFAULT NULL COMMENT '계열사코드',
  `ISDIRECT` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Y:직영/N:위탁',
  `UNAFFILIATE_SEQ` decimal(10,0) COMMENT '비계열코드',
  `USER_GROUP_SEQ` decimal(10,0) DEFAULT NULL COMMENT '사용자그룹코드',
  `OPEN_DT` date DEFAULT NULL COMMENT '개관일',
  `OPERATION` enum('Y','N') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y' COMMENT '운영여부(Y:운영,N:폐관)',
  `THEATER_NM` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '극장명필수' COMMENT '극장명',
  `ZIP` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '우편번호',
  `ADDR1` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '주소1',
  `ADDR2` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '주소2',
  `SCORE_TEL` enum('Y','N') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N' COMMENT '스코어 전화',
  `SCORE_FAX` enum('Y','N') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N' COMMENT '스코어 팩스',
  `SCORE_MAIL` enum('Y','N') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N' COMMENT '스코어 메일',
  `SCORE_SMS` enum('Y','N') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N' COMMENT '스코어 문자',
  `PREMIUM_TEL` enum('Y','N') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N' COMMENT '부금 전화',
  `PREMIUM_FAX` enum('Y','N') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N' COMMENT '부금 팩스',
  `PREMIUM_MAIL` enum('Y','N') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N' COMMENT '부금 메일',
  `PREMIUM_SMS` enum('Y','N') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N' COMMENT '부금 문자',
  `MEMO` text COLLATE utf8_unicode_ci COMMENT '비고(극장특징)',
  `FUND_FREE` enum('Y','N') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N' COMMENT '기금면제여부',
  `GUBUN_CODE` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '구분코드 ????',
  `SAUP_NO` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '사업자등록번호',
  `OWNER` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '대표자명',
  `SANGHO` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '상호',
  `HOMEPAGE` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '홈페이지',
  `IMAGES_NO` int(11) DEFAULT NULL COMMENT '이미지 첨부파일번호',
  PRIMARY KEY (`CODE`),
  KEY `FK_WRK_THEATER_BAS_ISDIRECT` (`ISDIRECT`),
  KEY `FK_WRK_THEATER_BAS_AFFILIATE` (`AFFILIATE_SEQ`),
  KEY `FK_WRK_THEATER_BAS_UNAFFILIATE` (`UNAFFILIATE_SEQ`),
  KEY `FK_WRK_THEATER_BAS_USER_GROUP` (`USER_GROUP_SEQ`),
  KEY `FK_WRK_THEATER_BAS_LOCATION_2` (`LOC2`),
  KEY `IDX_LOCATIONS` (`LOC1`,`LOC2`),
  CONSTRAINT `FK_WRK_THEATER_BAS_AFFILIATE` FOREIGN KEY (`AFFILIATE_SEQ`) REFERENCES `bas_affiliate` (`SEQ`),
  CONSTRAINT `FK_WRK_THEATER_BAS_ISDIRECT` FOREIGN KEY (`ISDIRECT`) REFERENCES `bas_isdirect` (`CODE`),
  CONSTRAINT `FK_WRK_THEATER_BAS_LOCATION_1` FOREIGN KEY (`LOC1`) REFERENCES `bas_location` (`SEQ`),
  CONSTRAINT `FK_WRK_THEATER_BAS_LOCATION_2` FOREIGN KEY (`LOC2`) REFERENCES `bas_location` (`SEQ`),
  CONSTRAINT `FK_WRK_THEATER_BAS_UNAFFILIATE` FOREIGN KEY (`UNAFFILIATE_SEQ`) REFERENCES `bas_unaffiliate` (`SEQ`),
  CONSTRAINT `FK_WRK_THEATER_BAS_USER_GROUP` FOREIGN KEY (`USER_GROUP_SEQ`) REFERENCES `bas_user_group` (`SEQ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='작업_극장 정보';

-- 테이블 데이터 my_test_db.wrk_theater:~36 rows (대략적) 내보내기
/*!40000 ALTER TABLE `wrk_theater` DISABLE KEYS */;
INSERT INTO `wrk_theater` (`CODE`, `LOC1`, `LOC2`, `AFFILIATE_SEQ`, `ISDIRECT`, `UNAFFILIATE_SEQ`, `USER_GROUP_SEQ`, `OPEN_DT`, `OPERATION`, `THEATER_NM`, `ZIP`, `ADDR1`, `ADDR2`, `SCORE_TEL`, `SCORE_FAX`, `SCORE_MAIL`, `SCORE_SMS`, `PREMIUM_TEL`, `PREMIUM_FAX`, `PREMIUM_MAIL`, `PREMIUM_SMS`, `MEMO`, `FUND_FREE`, `GUBUN_CODE`, `SAUP_NO`, `OWNER`, `SANGHO`, `HOMEPAGE`, `IMAGES_NO`) VALUES
	('TH0001', 100, 0, 0, '', 0, 0, '2014-12-15', 'Y', '극장1', '12345', '서울시...', '중앙동..', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '1111111\r\n22222222\r\n33333333', 'Y', '몰라몰라', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	('TH0002', 200, 202, 2, 'Y', 2, 2, '2013-12-16', 'Y', '극장명 2', NULL, NULL, NULL, 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', NULL, 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	('TH0003', 300, 301, 3, 'N', 3, 1, NULL, 'Y', '', NULL, NULL, NULL, 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', NULL, 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	('TH0004', 400, 402, 1, 'Y', 1, 2, NULL, 'Y', '', NULL, NULL, NULL, 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', NULL, 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	('TH0005', 500, 502, 2, 'N', 2, 2, NULL, 'Y', '', NULL, NULL, NULL, 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', NULL, 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	('TH0006', 0, 0, 0, '', 0, 0, '0000-00-00', 'N', '', '', '', '', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', '', 'N', '', '', '', '', '', NULL),
	('TH0013', 0, 0, 1, 'Y', 1, 1, NULL, 'Y', '', NULL, NULL, NULL, 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', NULL, 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	('TH0014', 0, 0, 1, 'N', 2, 1, NULL, 'Y', '', NULL, NULL, NULL, 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', NULL, 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	('TH0015', 0, 0, 0, 'N', 0, 1, '2016-12-27', 'Y', '극장명필수', NULL, NULL, NULL, 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', NULL, 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	('TH0016', 100, 101, 1, 'Y', 0, 0, '2016-12-30', '', '16번극장...', '49396', '부산광역시 사하구 구평동 을숙도대로7', 'ㄴㅇㄻㅇ', '', '', '', '', 'Y', 'Y', 'Y', 'Y', '1111\r\n22222\r\n333', 'Y', '구분코드.. 뭘..', '1234567890', '대표자', '상호', '홈페이지...', NULL),
	('TH0017', 0, 0, 0, '', 0, 0, '0000-00-00', 'Y', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0),
	('TH0018', 0, 0, 0, '', 0, 0, '0000-00-00', 'Y', '18극장', '17909', '경기도 평택시 신평동 자유로7번길', '', 'Y', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', '', 'N', '', '', '', '', '', NULL),
	('TH0019', 0, 0, 0, '', 0, 0, '0000-00-00', 'Y', '', '', '', '', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', '', 'N', '', '', '', '', '', NULL),
	('TH0020', 0, 0, 0, '', 0, 0, '0000-00-00', 'Y', '', '', '', '', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', '', 'N', '', '', '', '', '', NULL),
	('TH0021', 0, 0, 0, '', 0, 0, '0000-00-00', 'Y', '', '', '', '', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', '', 'N', '', '', '', '', '', NULL),
	('TH0022', 0, 0, 0, '', 0, 0, '0000-00-00', 'Y', '새극장명;...', '', '', '', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', '', 'N', '', '', '', '', '', NULL),
	('TH0023', 0, 0, 0, '', 0, 0, '0000-00-00', 'Y', '새극장명;...', '', '', '', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', '', 'N', '', '', '', '', '', NULL),
	('TH0024', 0, 0, 0, '', 0, 0, '0000-00-00', 'Y', '요금제 극자.....', '', '', '', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', '', 'N', '', '', '', '', '', NULL),
	('TH0025', 0, 0, 0, '', 0, 0, '0000-00-00', 'Y', '23213123', '', '', '', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', '', 'N', '', '', '', '', '', NULL),
	('TH0026', 0, 0, 0, '', 0, 0, '0000-00-00', 'Y', '23213123', '', '', '', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', '', 'N', '', '', '', '', '', NULL),
	('TH0027', 0, 0, 0, '', 0, 0, '0000-00-00', 'Y', '', '', '', '', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', '', 'N', '', '', '', '', '', NULL),
	('TH0028', 0, 0, 0, '', 0, 0, '0000-00-00', 'Y', '', '', '', '', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', '', 'N', '', '', '', '', '', NULL),
	('TH0029', 0, 0, 0, '', 0, 0, '0000-00-00', 'Y', '', '', '', '', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', '', 'N', '', '', '', '', '', NULL),
	('TH0030', 0, 0, 0, '', 0, 0, '0000-00-00', 'Y', '', '', '', '', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', '', 'N', '', '', '', '', '', NULL),
	('TH0031', 0, 0, 0, '', 0, 0, '0000-00-00', 'Y', '', '', '', '', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', '', 'N', '', '', '', '', '', NULL),
	('TH0032', 0, 0, 0, '', 0, 0, '0000-00-00', 'Y', '', '', '', '', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', '', 'N', '', '', '', '', '', NULL),
	('TH0033', 0, 0, 0, '', 0, 0, '0000-00-00', 'Y', '', '', '', '', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', '', 'N', '', '', '', '', '', NULL),
	('TH0034', 0, 0, 0, '', 0, 0, '0000-00-00', 'Y', '', '', '', '', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', '', 'N', '', '', '', '', '', NULL),
	('TH0035', 0, 0, 0, '', 0, 0, '0000-00-00', 'Y', '', '', '', '', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', '', 'N', '', '', '', '', '', NULL),
	('TH0036', 0, 0, 0, '', 0, 0, '0000-00-00', 'Y', '', '', '', '', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', '', 'N', '', '', '', '', '', NULL),
	('TH0037', 0, 0, 0, '', 0, 0, '0000-00-00', 'Y', '', '', '', '', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', '', 'N', '', '', '', '', '', NULL),
	('TH0038', 0, 0, 0, '', 0, 0, '0000-00-00', 'Y', '', '', '', '', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', '', 'N', '', '', '', '', '', NULL),
	('TH0039', 0, 0, 0, '', 0, 0, '0000-00-00', 'Y', '', '', '', '', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', '', 'N', '', '', '', '', '', NULL),
	('TH0040', 0, 0, 0, '', 0, 0, '0000-00-00', 'Y', '', '', '', '', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', '', 'N', '', '', '', '', '', NULL),
	('TH0041', 0, 0, 0, '', 0, 0, '0000-00-00', 'Y', '', '', '', '', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', '', 'N', '', '', '', '', '', NULL);
/*!40000 ALTER TABLE `wrk_theater` ENABLE KEYS */;


-- 테이블 my_test_db.wrk_theater_chghist 구조 내보내기
DROP TABLE IF EXISTS `wrk_theater_chghist`;
CREATE TABLE IF NOT EXISTS `wrk_theater_chghist` (
  `SEQ` decimal(10,0) unsigned NOT NULL DEFAULT '0' COMMENT '변경일련번호',
  `GUBUN` enum('INSERT','UPDATE') COLLATE utf8_unicode_ci NOT NULL COMMENT '추가/갱신',
  `THEATER_CODE` varchar(6) COLLATE utf8_unicode_ci NOT NULL COMMENT '극장코드(TH0001)',
  `CHANGE_DATE` date NOT NULL COMMENT '변경일',
  `CHANGE_TIME` time NOT NULL COMMENT '변경시간',
  `LOC1` decimal(10,0) DEFAULT NULL COMMENT '지역1',
  `LOC2` decimal(10,0) DEFAULT NULL COMMENT '지역2',
  `AFFILIATE_SEQ` decimal(10,0) DEFAULT NULL COMMENT '계열사코드',
  `ISDIRECT` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '직영여부',
  `UNAFFILIATE_SEQ` decimal(10,0) DEFAULT NULL COMMENT '비계열코드',
  `USER_GROUP_SEQ` decimal(10,0) DEFAULT NULL COMMENT '사용자그룹코드',
  `OPERATION` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '운영여부',
  `THEATER_NM` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '극장명',
  `FUND_FREE` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '기금면제여부',
  `GUBUN_CODE` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '구분코드??',
  `SAUP_NO` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '사업자등록번호',
  `OWNER` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '대표자명',
  `SANGHO` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '상호',
  `HOMEPAGE` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '홈페이지',
  `IMAGES_NO` int(11) DEFAULT NULL COMMENT '이미지 첨부파일번호',
  PRIMARY KEY (`SEQ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='작업_극장변경 정보';

-- 테이블 데이터 my_test_db.wrk_theater_chghist:~178 rows (대략적) 내보내기
/*!40000 ALTER TABLE `wrk_theater_chghist` DISABLE KEYS */;
INSERT INTO `wrk_theater_chghist` (`SEQ`, `GUBUN`, `THEATER_CODE`, `CHANGE_DATE`, `CHANGE_TIME`, `LOC1`, `LOC2`, `AFFILIATE_SEQ`, `ISDIRECT`, `UNAFFILIATE_SEQ`, `USER_GROUP_SEQ`, `OPERATION`, `THEATER_NM`, `FUND_FREE`, `GUBUN_CODE`, `SAUP_NO`, `OWNER`, `SANGHO`, `HOMEPAGE`, `IMAGES_NO`) VALUES
	(1, 'UPDATE', 'TH0002', '2016-12-17', '12:49:25', 200, 201, 2, 'N', 2, 2, 'Y', '극장명 2', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(2, 'UPDATE', 'TH0001', '2016-12-17', '12:49:25', 100, 101, 1, 'N', 1, 1, 'Y', '한글 극장명1', 'N', '2', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(3, 'UPDATE', 'TH0003', '2016-12-17', '12:49:25', 300, 301, 3, 'Y', 3, 1, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(4, 'UPDATE', 'TH0004', '2016-12-17', '12:49:25', 400, 402, 1, 'N', 1, 2, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(5, 'UPDATE', 'TH0005', '2016-12-17', '12:49:25', 500, 502, 2, 'Y', 2, 2, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(6, 'UPDATE', 'TH0006', '2016-12-17', '12:49:25', 0, 0, NULL, '', NULL, NULL, 'N', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(7, 'UPDATE', 'TH0007', '2016-12-17', '12:49:25', 0, 0, NULL, '', NULL, NULL, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(8, 'UPDATE', 'TH0008', '2016-12-17', '12:49:25', 0, 0, NULL, '', NULL, NULL, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(9, 'UPDATE', 'TH0009', '2016-12-17', '12:49:25', 0, 0, NULL, '', NULL, NULL, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(10, 'UPDATE', 'TH0011', '2016-12-17', '12:49:25', 0, 0, NULL, '', NULL, NULL, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(11, 'UPDATE', 'TH0010', '2016-12-17', '12:49:25', 0, 0, NULL, '', NULL, NULL, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(12, 'UPDATE', 'TH0013', '2016-12-17', '12:49:25', 0, 0, NULL, '', NULL, NULL, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(13, 'UPDATE', 'TH0012', '2016-12-17', '12:49:25', 0, 0, NULL, '', NULL, NULL, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(14, 'UPDATE', 'TH0014', '2016-12-17', '12:49:25', 0, 0, NULL, '', NULL, NULL, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(15, 'UPDATE', 'TH0015', '2016-12-17', '12:49:25', 0, 0, NULL, '', NULL, NULL, 'Y', '극장명필수', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(16, 'UPDATE', 'TH0014', '2016-12-17', '18:20:48', 0, 0, NULL, 'N', NULL, NULL, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(17, 'UPDATE', 'TH0014', '2016-12-17', '18:20:56', 0, 0, NULL, '', NULL, NULL, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(18, 'UPDATE', 'TH0009', '2016-12-17', '18:21:37', 0, 0, NULL, 'N', NULL, NULL, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(19, 'UPDATE', 'TH0006', '2016-12-17', '18:25:58', 0, 0, NULL, 'Y', NULL, NULL, 'N', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(20, 'UPDATE', 'TH0006', '2016-12-17', '18:26:06', 0, 0, 0, 'Y', NULL, NULL, 'N', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(21, 'UPDATE', 'TH0007', '2016-12-17', '18:26:10', 0, 0, NULL, 'N', NULL, NULL, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(22, 'UPDATE', 'TH0007', '2016-12-17', '18:26:42', 0, 0, NULL, 'N', 0, NULL, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(23, 'UPDATE', 'TH0007', '2016-12-17', '18:26:46', 0, 0, NULL, '', 0, NULL, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(24, 'UPDATE', 'TH0007', '2016-12-17', '18:26:50', 0, 0, 1, '', 0, NULL, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(25, 'UPDATE', 'TH0006', '2016-12-17', '18:33:21', 0, 0, 0, 'Y', 0, NULL, 'N', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(26, 'UPDATE', 'TH0008', '2016-12-17', '19:01:35', 0, 0, NULL, 'Y', NULL, NULL, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(27, 'UPDATE', 'TH0008', '2016-12-17', '19:01:41', 0, 0, NULL, 'Y', 0, NULL, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(28, 'UPDATE', 'TH0007', '2016-12-17', '19:03:09', 0, 0, 0, '', 0, NULL, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(29, 'UPDATE', 'TH0006', '2016-12-17', '19:03:12', 400, 403, 0, 'Y', 0, NULL, 'N', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(30, 'UPDATE', 'TH0011', '2016-12-17', '19:03:22', 0, 0, NULL, 'Y', NULL, NULL, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(31, 'UPDATE', 'TH0010', '2016-12-17', '19:03:25', 0, 0, NULL, 'N', NULL, NULL, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(32, 'UPDATE', 'TH0008', '2016-12-17', '19:03:29', 0, 0, 0, 'Y', 0, NULL, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(33, 'UPDATE', 'TH0010', '2016-12-17', '19:03:31', 0, 0, NULL, 'N', NULL, NULL, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(34, 'UPDATE', 'TH0012', '2016-12-17', '19:03:33', 0, 0, NULL, 'Y', NULL, NULL, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(35, 'UPDATE', 'TH0014', '2016-12-17', '19:03:35', 0, 0, NULL, 'N', NULL, NULL, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(36, 'UPDATE', 'TH0013', '2016-12-17', '19:03:38', 0, 0, NULL, 'Y', NULL, NULL, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(37, 'UPDATE', 'TH0011', '2016-12-17', '19:03:43', 0, 0, NULL, 'Y', NULL, NULL, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(38, 'UPDATE', 'TH0009', '2016-12-17', '19:03:47', 0, 0, 3, 'N', NULL, NULL, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(39, 'UPDATE', 'TH0011', '2016-12-17', '19:03:49', 0, 0, NULL, 'Y', NULL, 1, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(40, 'UPDATE', 'TH0013', '2016-12-17', '19:03:52', 0, 0, NULL, 'Y', NULL, 1, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(41, 'UPDATE', 'TH0014', '2016-12-17', '19:03:55', 0, 0, NULL, 'N', NULL, 1, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(42, 'UPDATE', 'TH0015', '2016-12-17', '19:03:58', 0, 0, NULL, 'N', NULL, NULL, 'Y', '극장명필수', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(43, 'UPDATE', 'TH0013', '2016-12-17', '19:04:01', 0, 0, NULL, 'Y', 1, 1, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(44, 'UPDATE', 'TH0012', '2016-12-17', '19:04:03', 0, 0, NULL, 'Y', NULL, 0, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(45, 'UPDATE', 'TH0011', '2016-12-17', '19:04:06', 0, 0, NULL, 'Y', 3, 1, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(46, 'UPDATE', 'TH0010', '2016-12-17', '19:04:08', 0, 0, NULL, 'N', NULL, 1, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(47, 'UPDATE', 'TH0001', '2016-12-18', '09:15:11', 100, 101, 1, 'N', 1, 1, 'Y', '한글 극장명1', 'N', '2', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(48, 'UPDATE', 'TH0001', '2016-12-18', '09:17:54', 100, 101, 1, 'N', 1, 1, 'Y', '한글 극장명1', 'N', '2', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(49, 'UPDATE', 'TH0001', '2016-12-18', '09:19:27', 100, 101, 1, 'N', 1, 1, 'Y', '한글 극장명1', 'N', '2', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(50, 'UPDATE', 'TH0001', '2016-12-18', '09:20:46', 100, 101, 1, 'N', 1, 1, 'Y', '한글 극장명1', 'N', '2', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(51, 'UPDATE', 'TH0001', '2016-12-18', '09:21:08', 100, 101, 1, 'N', 1, 1, 'Y', '한글 극장명1', 'N', '2', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(52, 'UPDATE', 'TH0001', '2016-12-18', '09:29:01', 100, 101, 1, 'N', 1, 1, 'Y', '한글 극장명1', 'N', '2', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(53, 'UPDATE', 'TH0001', '2016-12-18', '09:38:27', 100, 101, 1, 'N', 1, 1, 'Y', '한글 극장명1', 'N', '2', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(54, 'UPDATE', 'TH0001', '2016-12-18', '10:25:02', 100, 101, 1, 'N', 1, 1, 'Y', '한글 극장명1', 'N', '2', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(55, 'UPDATE', 'TH0001', '2016-12-18', '10:27:07', 100, 101, 1, 'N', 1, 1, 'Y', '한글 극장명1', 'N', '2', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(56, 'UPDATE', 'TH0001', '2016-12-19', '00:04:45', 100, 101, 1, 'N', 1, 1, 'Y', '한글 극장명1', 'N', '2', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(57, 'UPDATE', 'TH0001', '2016-12-19', '00:08:15', 100, 101, 3, 'N', 1, 1, 'Y', '한글 극장명1', 'N', '2', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(58, 'UPDATE', 'TH0001', '2016-12-19', '00:08:31', 100, 101, 1, 'N', 1, 1, 'Y', '한글 극장명1', 'N', '2', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(59, 'UPDATE', 'TH0001', '2016-12-19', '00:09:38', 100, 101, 1, 'Y', 1, 1, 'Y', '한글 극장명1', 'N', '2', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(60, 'UPDATE', 'TH0001', '2016-12-19', '00:10:25', 100, 101, 1, 'N', 1, 1, 'Y', '한글 극장명1', 'N', '2', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(61, 'UPDATE', 'TH0001', '2016-12-19', '00:10:45', 100, 101, 1, 'N', 3, 2, 'Y', '한글 극장명1', 'N', '2', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(62, 'UPDATE', 'TH0001', '2016-12-19', '00:11:15', 100, 101, 1, 'N', 1, 1, 'Y', '한글 극장명1', 'N', '2', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(63, 'UPDATE', 'TH0001', '2016-12-19', '00:11:29', 100, 101, 1, 'N', 1, 0, 'Y', '한글 극장명1', 'N', '2', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(64, 'UPDATE', 'TH0001', '2016-12-19', '00:11:45', 100, 101, 1, 'N', 1, 2, 'Y', '한글 극장명1', 'N', '2', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(65, 'UPDATE', 'TH0001', '2016-12-19', '00:12:19', 100, 101, 1, 'N', 1, 2, 'Y', '한글 극장명1', 'N', '2', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(66, 'UPDATE', 'TH0001', '2016-12-19', '00:12:32', 100, 101, 1, 'N', 1, 2, 'Y', '한글 극장명2', 'N', '2', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(67, 'UPDATE', 'TH0001', '2016-12-19', '00:13:49', 100, 101, 1, 'N', 1, 2, 'Y', '한글 극장명3', 'N', '2', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(68, 'UPDATE', 'TH0001', '2016-12-19', '00:14:10', 100, 101, 1, 'N', 1, 2, 'Y', '한글 극장명', 'N', '2', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(69, 'UPDATE', 'TH0001', '2016-12-19', '00:14:31', 100, 101, 1, 'N', 1, 2, 'Y', '라ㅓㄹ남', 'N', '2', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(70, 'UPDATE', 'TH0012', '2016-12-21', '20:58:10', 0, 0, 1, 'Y', NULL, 0, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(71, 'UPDATE', 'TH0010', '2016-12-21', '20:58:13', 0, 0, 1, 'N', NULL, 1, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(72, 'UPDATE', 'TH0014', '2016-12-21', '20:58:15', 0, 0, NULL, 'N', 2, 1, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(73, 'UPDATE', 'TH0015', '2016-12-21', '20:58:20', 0, 0, NULL, 'N', 0, NULL, 'Y', '극장명필수', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(74, 'UPDATE', 'TH0015', '2016-12-21', '20:58:26', 0, 0, 0, 'N', 0, NULL, 'Y', '극장명필수', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(75, 'UPDATE', 'TH0001', '2016-12-28', '00:33:48', 100, 101, 1, 'N', 1, 2, 'Y', '극장1', 'N', '2', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(76, 'UPDATE', 'TH0001', '2016-12-28', '00:38:11', 100, 101, 1, 'N', 1, 2, 'Y', '극장1', 'N', '몰라몰라', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(77, 'UPDATE', 'TH0016', '2016-12-28', '01:26:13', 400, 401, 1, 'N', 1, 2, 'Y', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(78, 'UPDATE', 'TH0015', '2016-12-28', '11:00:44', 0, 0, 0, 'N', 0, 1, 'Y', '극장명필수', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(79, 'UPDATE', 'TH0016', '2016-12-28', '11:45:26', 0, 0, 0, '', 0, 0, '', '', '', '', '', '', '', '', 0),
	(80, 'UPDATE', 'TH0016', '2016-12-28', '12:05:36', 0, 0, 0, '', 0, 0, '', '111', '', '', '', '', '', '', NULL),
	(81, 'UPDATE', 'TH0016', '2016-12-28', '12:06:57', 0, 0, 0, '', 0, 0, '', '111', 'Y', '65', '', '', '', '', NULL),
	(82, 'UPDATE', 'TH0016', '2016-12-28', '12:07:27', 300, 302, 1, 'Y', 0, 0, '', '111', 'Y', '65', '1234567890', '대표자', '상호', '홈페이지...', NULL),
	(83, 'UPDATE', 'TH0016', '2016-12-28', '12:07:54', 400, 401, 1, 'Y', 0, 0, '', '111', 'Y', '65', '1234567890', '대표자', '상호', '홈페이지...', NULL),
	(84, 'UPDATE', 'TH0016', '2016-12-28', '12:08:49', 400, 401, 1, 'Y', 1, 1, '', '111', 'Y', '65', '1234567890', '대표자', '상호', '홈페이지...', NULL),
	(85, 'UPDATE', 'TH0016', '2016-12-28', '12:09:44', 400, 401, 1, 'Y', 1, 1, '', '111', 'Y', '65', '1234567890', '대표자', '상호', '홈페이지...', NULL),
	(86, 'UPDATE', 'TH0016', '2016-12-28', '12:10:31', 400, 401, 1, 'Y', 1, 0, '', '16번극장...', 'Y', '65', '1234567890', '대표자', '상호', '홈페이지...', NULL),
	(87, 'UPDATE', 'TH0016', '2016-12-28', '12:11:03', 400, 401, 1, 'Y', 0, 0, '', '16번극장...', 'Y', '65', '1234567890', '대표자', '상호', '홈페이지...', NULL),
	(88, 'UPDATE', 'TH0016', '2016-12-28', '12:11:33', 400, 401, 1, 'Y', 0, 0, '', '16번극장...', 'Y', '65', '1234567890', '대표자', '상호', '홈페이지...', NULL),
	(89, 'UPDATE', 'TH0016', '2016-12-28', '19:33:07', 400, 401, 1, 'Y', 0, 0, '', '16번극장...', 'Y', '구분코드.. 뭘..', '1234567890', '대표자', '상호', '홈페이지...', NULL),
	(90, 'UPDATE', 'TH0016', '2016-12-28', '19:34:06', 400, 401, 1, 'Y', 0, 0, '', '16번극장...', 'Y', '구분코드.. 뭘..', '1234567890', '대표자', '상호', '홈페이지...', NULL),
	(91, 'UPDATE', 'TH0016', '2016-12-28', '20:26:40', 100, 101, 1, 'Y', 0, 0, '', '16번극장...', 'Y', '구분코드.. 뭘..', '1234567890', '대표자', '상호', '홈페이지...', NULL),
	(92, 'UPDATE', 'TH0016', '2016-12-28', '20:27:40', 100, 101, 1, 'Y', 0, 0, '', '16번극장...', 'Y', '구분코드.. 뭘..', '1234567890', '대표자', '상호', '홈페이지...', NULL),
	(93, 'INSERT', 'TH0017', '2016-12-28', '21:17:04', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(94, 'INSERT', 'TH0018', '2016-12-28', '21:17:52', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(95, 'INSERT', 'TH0019', '2016-12-28', '21:21:46', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(96, 'INSERT', 'TH0020', '2016-12-28', '21:23:27', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(97, 'INSERT', 'TH0021', '2016-12-28', '21:27:20', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(98, 'INSERT', 'TH0022', '2016-12-28', '21:31:06', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(99, 'INSERT', 'TH0018', '2016-12-28', '21:34:11', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(100, 'INSERT', 'TH0019', '2016-12-28', '22:52:21', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(101, 'INSERT', 'TH0020', '2016-12-28', '22:58:42', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(102, 'INSERT', 'TH0021', '2016-12-28', '22:59:11', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(103, 'INSERT', 'TH0022', '2016-12-28', '23:00:35', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(104, 'INSERT', 'TH0023', '2016-12-28', '23:00:54', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(105, 'INSERT', 'TH0024', '2016-12-28', '23:02:28', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(106, 'INSERT', 'TH0025', '2016-12-28', '23:05:54', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(107, 'INSERT', 'TH0026', '2016-12-28', '23:08:26', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(108, 'INSERT', 'TH0027', '2016-12-28', '23:10:27', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(109, 'INSERT', 'TH0028', '2016-12-28', '23:11:19', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(110, 'INSERT', 'TH0029', '2016-12-28', '23:13:26', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(111, 'INSERT', 'TH0030', '2016-12-28', '23:13:36', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(112, 'UPDATE', 'TH0022', '2016-12-28', '23:30:26', 0, 0, 0, '', 0, 0, 'Y', '새로운 극장...', 'N', '', '', '', '', '', NULL),
	(113, 'UPDATE', 'TH0021', '2016-12-28', '23:30:57', 0, 0, 0, '', 0, 0, 'Y', '새로운 극장...', 'N', '', '', '', '', '', NULL),
	(114, 'UPDATE', 'TH0025', '2016-12-28', '23:31:27', 0, 0, 0, '', 0, 0, 'Y', '새로운 극장...', 'N', '', '', '', '', '', NULL),
	(115, 'UPDATE', 'TH0018', '2016-12-28', '23:32:19', 0, 0, 0, '', 0, 0, 'Y', 'ㅇㄴㄹ', 'N', '', '', '', '', '', NULL),
	(116, 'UPDATE', 'TH0028', '2016-12-28', '23:32:58', 0, 0, 0, '', 0, 0, 'Y', '완전새극장.....', 'N', '', '', '', '', '', NULL),
	(117, 'UPDATE', 'TH0026', '2016-12-28', '23:38:14', 0, 0, 0, '', 0, 0, 'Y', '새로운 극장...', 'N', '', '', '', '', '', NULL),
	(118, 'UPDATE', 'TH0026', '2016-12-28', '23:51:42', 0, 0, 0, '', 0, 0, 'Y', '새로운 극장...26', 'N', '', '', '', '', '', NULL),
	(119, 'UPDATE', 'TH0020', '2016-12-29', '12:59:30', 0, 0, 0, '', 0, 0, 'Y', '새로운 극장...', 'N', '', '', '', '', '', NULL),
	(120, 'UPDATE', 'TH0020', '2016-12-29', '14:36:28', 0, 0, 0, '', 0, 0, 'Y', '새로운 극장...', 'N', '', '', '', '', '', NULL),
	(121, 'UPDATE', 'TH0020', '2016-12-29', '14:37:08', 0, 0, 0, '', 0, 0, 'Y', '새로운 극장...', 'N', '', '', '', '', '', NULL),
	(122, 'UPDATE', 'TH0020', '2016-12-29', '14:37:18', 0, 0, 0, '', 0, 0, 'Y', '새로운 극장...', 'N', '', '', '', '', '', NULL),
	(123, 'UPDATE', 'TH0020', '2016-12-29', '14:37:36', 0, 0, 0, '', 0, 0, 'Y', '새로운 극장...', 'N', '', '', '', '', '', NULL),
	(124, 'UPDATE', 'TH0020', '2016-12-29', '14:38:40', 0, 0, 0, '', 0, 0, 'Y', '새로운 극장...', 'N', '', '', '', '', '', NULL),
	(125, 'UPDATE', 'TH0020', '2016-12-29', '14:38:53', 0, 0, 0, '', 0, 0, 'Y', '새로운 극장...', 'N', '', '', '', '', '', NULL),
	(126, 'UPDATE', 'TH0020', '2016-12-29', '14:39:09', 0, 0, 0, '', 0, 0, 'Y', '새로운 극장...', 'N', '', '', '', '', '', NULL),
	(127, 'UPDATE', 'TH0020', '2016-12-29', '14:39:33', 0, 0, 0, '', 0, 0, 'Y', '새로운 극장...', 'N', '', '', '', '', '', NULL),
	(128, 'INSERT', 'TH0031', '2016-12-29', '14:39:59', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(129, 'INSERT', 'TH0032', '2016-12-29', '14:40:32', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(130, 'UPDATE', 'TH0018', '2016-12-29', '14:43:24', 0, 0, 0, '', 0, 0, 'Y', '18극장', 'N', '', '', '', '', '', NULL),
	(131, 'UPDATE', 'TH0001', '2016-12-30', '00:35:11', 100, 101, 1, 'N', 1, 2, 'Y', '극장1', 'Y', '몰라몰라', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(132, 'UPDATE', 'TH0006', '2016-12-30', '00:35:24', 400, 403, 0, 'Y', 0, 0, 'N', '', 'N', NULL, NULL, NULL, NULL, NULL, NULL),
	(133, 'UPDATE', 'TH0006', '2016-12-30', '00:37:04', 400, 403, 0, 'Y', 0, 0, 'N', '', 'N', '', '', '', '', '', NULL),
	(134, 'UPDATE', 'TH0001', '2016-12-30', '01:41:00', 100, 101, 1, 'N', 1, 0, 'Y', '극장1', 'Y', '몰라몰라', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(135, 'UPDATE', 'TH0001', '2016-12-30', '01:41:06', 100, 101, 1, 'N', 0, 0, 'Y', '극장1', 'Y', '몰라몰라', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(136, 'UPDATE', 'TH0001', '2016-12-30', '01:44:13', 100, 101, 1, 'N', 0, 0, 'Y', '극장1', 'Y', '몰라몰라', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(137, 'UPDATE', 'TH0001', '2016-12-30', '01:46:45', 100, 101, 1, 'N', 0, 0, 'Y', '극장1', 'Y', '몰라몰라', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(138, 'UPDATE', 'TH0001', '2016-12-30', '01:50:08', 100, 0, 1, '', 0, 0, 'Y', '극장1', 'Y', '몰라몰라', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(139, 'UPDATE', 'TH0001', '2016-12-30', '01:52:14', 100, 0, 1, '', 0, 0, 'Y', '극장1', 'Y', '몰라몰라', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(140, 'UPDATE', 'TH0001', '2016-12-30', '01:52:37', 100, 0, 1, '', 0, 0, 'Y', '극장1', 'Y', '몰라몰라', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(141, 'UPDATE', 'TH0001', '2016-12-30', '02:18:33', 100, 0, 1, '', 0, 0, 'Y', '극장1', 'Y', '몰라몰라', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(142, 'UPDATE', 'TH0001', '2016-12-31', '06:46:38', 100, 0, 1, '', 0, 0, 'Y', '극장1', 'Y', '몰라몰라', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(143, 'UPDATE', 'TH0001', '2016-12-31', '06:47:02', 100, 0, 1, '', 0, 0, 'Y', '극장1', 'Y', '몰라몰라', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(144, 'INSERT', 'TH0019', '2016-12-31', '07:03:37', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(145, 'UPDATE', 'TH0001', '2016-12-31', '07:03:59', 100, 0, 0, '', 0, 0, 'Y', '극장1', 'Y', '몰라몰라', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(146, 'UPDATE', 'TH0001', '2016-12-31', '07:09:14', 100, 0, 0, '', 0, 0, 'Y', '극장1', 'Y', '몰라몰라', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(147, 'INSERT', 'TH0020', '2016-12-31', '07:09:40', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(148, 'INSERT', 'TH0021', '2016-12-31', '07:12:52', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(149, 'UPDATE', 'TH0001', '2016-12-31', '07:13:08', 100, 0, 0, '', 0, 0, 'Y', '극장1', 'Y', '몰라몰라', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(150, 'UPDATE', 'TH0001', '2017-01-01', '19:34:22', 100, 0, 0, '', 0, 0, 'Y', '극장1', 'Y', '몰라몰라', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(151, 'UPDATE', 'TH0001', '2017-01-01', '19:37:44', 100, 0, 0, '', 0, 0, 'Y', '극장1', 'Y', '몰라몰라', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(152, 'UPDATE', 'TH0001', '2017-01-01', '19:38:13', 100, 0, 0, '', 0, 0, 'Y', '극장1', 'Y', '몰라몰라', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(153, 'UPDATE', 'TH0001', '2017-01-01', '19:38:46', 100, 0, 0, '', 0, 0, 'Y', '극장1', 'Y', '몰라몰라', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(154, 'INSERT', 'TH0022', '2017-01-01', '19:40:38', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(155, 'INSERT', 'TH0023', '2017-01-01', '19:41:15', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(156, 'INSERT', 'TH0024', '2017-01-01', '19:42:01', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(157, 'INSERT', 'TH0022', '2017-01-01', '19:44:53', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(158, 'INSERT', 'TH0023', '2017-01-01', '19:45:20', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(159, 'UPDATE', 'TH0001', '2017-01-01', '19:45:36', 100, 0, 0, '', 0, 0, 'Y', '극장1', 'Y', '몰라몰라', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(160, 'INSERT', 'TH0024', '2017-01-01', '20:37:09', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(161, 'INSERT', 'TH0025', '2017-01-01', '20:40:27', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(162, 'INSERT', 'TH0026', '2017-01-01', '20:41:46', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(163, 'INSERT', 'TH0027', '2017-01-01', '20:42:00', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(164, 'INSERT', 'TH0028', '2017-01-01', '20:42:45', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(165, 'INSERT', 'TH0029', '2017-01-01', '20:43:12', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(166, 'INSERT', 'TH0030', '2017-01-01', '20:43:59', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(167, 'INSERT', 'TH0031', '2017-01-01', '20:44:25', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(168, 'INSERT', 'TH0032', '2017-01-01', '20:46:50', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(169, 'INSERT', 'TH0033', '2017-01-01', '20:48:02', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(170, 'INSERT', 'TH0034', '2017-01-01', '20:48:19', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(171, 'INSERT', 'TH0035', '2017-01-01', '20:49:56', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(172, 'INSERT', 'TH0036', '2017-01-01', '20:53:10', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(173, 'INSERT', 'TH0037', '2017-01-01', '20:53:25', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(174, 'INSERT', 'TH0038', '2017-01-01', '20:56:12', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(175, 'INSERT', 'TH0039', '2017-01-01', '20:57:10', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(176, 'INSERT', 'TH0040', '2017-01-01', '20:58:26', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(177, 'INSERT', 'TH0041', '2017-01-01', '21:00:26', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(178, 'INSERT', 'TH0042', '2017-01-01', '21:05:16', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(179, 'UPDATE', 'TH0001', '2017-01-01', '21:07:44', 100, 0, 0, '', 0, 0, 'Y', '극장1', 'Y', '몰라몰라', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(180, 'UPDATE', 'TH0042', '2017-01-01', '21:15:51', 0, 0, 0, '', 0, 0, 'Y', '', 'N', '', '', '', '', '', NULL),
	(181, 'UPDATE', 'TH0001', '2017-01-01', '21:17:14', 100, 0, 0, '', 0, 0, 'Y', '극장1', 'Y', '몰라몰라', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL),
	(182, 'UPDATE', 'TH0001', '2017-01-01', '21:17:25', 100, 0, 0, '', 0, 0, 'Y', '극장1', 'Y', '몰라몰라', '1234', '주인장', '상호', 'WWW.SDAFFD.CPM', NULL);
/*!40000 ALTER TABLE `wrk_theater_chghist` ENABLE KEYS */;


-- 테이블 my_test_db.wrk_theater_distributor 구조 내보내기
DROP TABLE IF EXISTS `wrk_theater_distributor`;
CREATE TABLE IF NOT EXISTS `wrk_theater_distributor` (
  `SEQ` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '일련번호',
  `THEATER_CODE` varchar(6) COLLATE utf8_unicode_ci NOT NULL COMMENT '극장코드(TH0001)',
  `DISTRIBUTOR_SEQ` decimal(10,0) NOT NULL COMMENT '배급사일련번호',
  `THEATER_KNM` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '극장명(한글)',
  `THEATER_ENM` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '극장명(영문)',
  `THEATER_DCODE` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '배급사 극장코드',
  PRIMARY KEY (`SEQ`),
  KEY `FK_WRK_THEATER_DISTRIBUTOR_BAS_DISTRIBUTOR` (`DISTRIBUTOR_SEQ`),
  KEY `FK_WRK_THEATER_DISTRIBUTOR_WRK_THEATER` (`THEATER_CODE`),
  CONSTRAINT `FK_WRK_THEATER_DISTRIBUTOR_BAS_DISTRIBUTOR` FOREIGN KEY (`DISTRIBUTOR_SEQ`) REFERENCES `bas_distributor` (`SEQ`),
  CONSTRAINT `FK_WRK_THEATER_DISTRIBUTOR_WRK_THEATER` FOREIGN KEY (`THEATER_CODE`) REFERENCES `wrk_theater` (`CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='작업_극장의 배급사 정보';

-- 테이블 데이터 my_test_db.wrk_theater_distributor:~2 rows (대략적) 내보내기
/*!40000 ALTER TABLE `wrk_theater_distributor` DISABLE KEYS */;
INSERT INTO `wrk_theater_distributor` (`SEQ`, `THEATER_CODE`, `DISTRIBUTOR_SEQ`, `THEATER_KNM`, `THEATER_ENM`, `THEATER_DCODE`) VALUES
	(1, 'TH0001', 1, '극장1', NULL, NULL),
	(2, 'TH0001', 2, '극장5', NULL, NULL);
/*!40000 ALTER TABLE `wrk_theater_distributor` ENABLE KEYS */;


-- 테이블 my_test_db.wrk_theater_unitprice 구조 내보내기
DROP TABLE IF EXISTS `wrk_theater_unitprice`;
CREATE TABLE IF NOT EXISTS `wrk_theater_unitprice` (
  `THEATER_CODE` varchar(6) COLLATE utf8_unicode_ci NOT NULL COMMENT '극장코드(TH0001)',
  `UNIT_PRICE_SEQ` decimal(10,0) NOT NULL COMMENT '단가',
  PRIMARY KEY (`THEATER_CODE`,`UNIT_PRICE_SEQ`),
  KEY `FK_WRK_THEATER_UNITPRICE_BAS_UNITPRICE` (`UNIT_PRICE_SEQ`),
  CONSTRAINT `FK_WRK_THEATER_UNITPRICE_BAS_UNITPRICE` FOREIGN KEY (`UNIT_PRICE_SEQ`) REFERENCES `bas_unitprice` (`SEQ`),
  CONSTRAINT `FK_WRK_UNITPRICE_WRK_THEATER` FOREIGN KEY (`THEATER_CODE`) REFERENCES `wrk_theater` (`CODE`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='작업_극장의 단가 정보';

-- 테이블 데이터 my_test_db.wrk_theater_unitprice:~6 rows (대략적) 내보내기
/*!40000 ALTER TABLE `wrk_theater_unitprice` DISABLE KEYS */;
INSERT INTO `wrk_theater_unitprice` (`THEATER_CODE`, `UNIT_PRICE_SEQ`) VALUES
	('TH0001', 1),
	('TH0030', 1),
	('TH0030', 2),
	('TH0030', 3),
	('TH0030', 4),
	('TH0001', 12);
/*!40000 ALTER TABLE `wrk_theater_unitprice` ENABLE KEYS */;


-- 뷰 my_test_db.VW_BJD_LIST 구조 내보내기
DROP VIEW IF EXISTS `VW_BJD_LIST`;
-- VIEW 종속성 오류를 극복하기 위해 임시 테이블을 생성합니다.
CREATE TABLE `VW_BJD_LIST` (
	`DO_CODE` INT(1) NOT NULL,
	`CITY_CODE` INT(1) NOT NULL,
	`KU_CODE` INT(1) NOT NULL,
	`DONG_CODE` INT(1) NOT NULL,
	`LEE_CODE` INT(1) NOT NULL,
	`BJD_NAME` INT(1) NOT NULL
) ENGINE=MyISAM;


-- 뷰 my_test_db.VW_BJD_LIST_FULL 구조 내보내기
DROP VIEW IF EXISTS `VW_BJD_LIST_FULL`;
-- VIEW 종속성 오류를 극복하기 위해 임시 테이블을 생성합니다.
CREATE TABLE `VW_BJD_LIST_FULL` (
	`DO_CODE` INT(1) NOT NULL,
	`CITY_CODE` INT(1) NOT NULL,
	`KU_CODE` INT(1) NOT NULL,
	`DONG_CODE` INT(1) NOT NULL,
	`LEE_CODE` INT(1) NOT NULL,
	`BJD_NAME` INT(1) NOT NULL,
	`DO_NAME` INT(1) NOT NULL,
	`CITY_NAME` INT(1) NOT NULL,
	`KU_NAME` INT(1) NOT NULL,
	`DONG_NAME` INT(1) NOT NULL,
	`LEE_NAME` INT(1) NOT NULL
) ENGINE=MyISAM;


-- 프로시저 my_test_db.GET_COLUNMS_BY_TABLE_FIELD 구조 내보내기
DROP PROCEDURE IF EXISTS `GET_COLUNMS_BY_TABLE_FIELD`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `GET_COLUNMS_BY_TABLE_FIELD`(IN `P_TABLE_NAME` VARCHAR(20))
    COMMENT '특정 테이블의 컬럼 정보를 구한다.'
BEGIN

    SELECT COLUMN_NAME
      FROM INFORMATION_SCHEMA.COLUMNS 
     WHERE TABLE_NAME = P_TABLE_NAME  COLLATE utf8_unicode_ci 
      AND TABLE_SCHEMA = DATABASE()
  ORDER BY ORDINAL_POSITION
           ;
 
END//
DELIMITER ;


-- 프로시저 my_test_db.GET_COLUNMS_BY_TABLE_FULL 구조 내보내기
DROP PROCEDURE IF EXISTS `GET_COLUNMS_BY_TABLE_FULL`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `GET_COLUNMS_BY_TABLE_FULL`(IN `P_TABLE_NAME` VARCHAR(20))
    NO SQL
    COMMENT '특정 테이블의 컬럼 정보를 구한다.'
BEGIN

    SELECT COLUMN_COMMENT
          ,COLUMN_NAME
          ,ORDINAL_POSITION
          ,COLUMN_DEFAULT
          ,IS_NULLABLE
          ,DATA_TYPE
          ,CHARACTER_MAXIMUM_LENGTH
          ,CHARACTER_OCTET_LENGTH
          ,NUMERIC_PRECISION
          ,NUMERIC_SCALE
          ,DATETIME_PRECISION
          ,CHARACTER_SET_NAME
          ,COLLATION_NAME
          ,COLUMN_TYPE
          ,COLUMN_KEY
          ,EXTRA
          ,PRIVILEGES          
      FROM INFORMATION_SCHEMA.COLUMNS 
     WHERE TABLE_NAME = P_TABLE_NAME  COLLATE utf8_unicode_ci 
       AND TABLE_SCHEMA = DATABASE()
  ORDER BY ORDINAL_POSITION
           ;
 
END//
DELIMITER ;


-- 프로시저 my_test_db.GET_COLUNMS_BY_TABLE_SIMPLE 구조 내보내기
DROP PROCEDURE IF EXISTS `GET_COLUNMS_BY_TABLE_SIMPLE`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `GET_COLUNMS_BY_TABLE_SIMPLE`(IN `P_TABLE_NAME` VARCHAR(20))
    NO SQL
    COMMENT '특정 테이블의 컬럼 정보를 구한다.'
BEGIN

    SELECT COLUMN_NAME
          ,COLUMN_COMMENT
      FROM INFORMATION_SCHEMA.COLUMNS 
     WHERE TABLE_NAME = P_TABLE_NAME  COLLATE utf8_unicode_ci 
       AND TABLE_SCHEMA = DATABASE()
  ORDER BY ORDINAL_POSITION 
           ;
 
END//
DELIMITER ;


-- 프로시저 my_test_db.GET_NAMME_BY_ROUTINE_DEFINITION 구조 내보내기
DROP PROCEDURE IF EXISTS `GET_NAMME_BY_ROUTINE_DEFINITION`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `GET_NAMME_BY_ROUTINE_DEFINITION`(IN `P_KEYWORD` VARCHAR(50))
    COMMENT '프로시져나 함수의 내용을 키워드로 이름을 구한다. 예) logwrite'
BEGIN

    SELECT ROUTINE_NAME 
      FROM INFORMATION_SCHEMA.ROUTINES
     WHERE ROUTINE_DEFINITION LIKE CONCAT('%',P_KEYWORD COLLATE utf8_unicode_ci ,'%')
       AND ROUTINE_SCHEMA = DATABASE()
           ;
           
END//
DELIMITER ;


-- 프로시저 my_test_db.handlerdemo 구조 내보내기
DROP PROCEDURE IF EXISTS `handlerdemo`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `handlerdemo`()
BEGIN
       DECLARE CONTINUE HANDLER FOR SQLSTATE '23000' SET @x2 = 1;
       SET @x = 1;
       INSERT INTO test.t VALUES (1);
       SET @x = 2;
       INSERT INTO test.t VALUES (1);
       SET @x = 3;
     END//
DELIMITER ;


-- 프로시저 my_test_db.log 구조 내보내기
DROP PROCEDURE IF EXISTS `log`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `log`()
    COMMENT '디버깅용 로그 보기'
BEGIN

     SELECT * 
       FROM tmp_log
   ORDER BY seq DESC
            ;
 
END//
DELIMITER ;


-- 프로시저 my_test_db.logclear 구조 내보내기
DROP PROCEDURE IF EXISTS `logclear`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `logclear`()
    COMMENT '디버깅용 로그지우기'
BEGIN

    DELETE FROM tmp_log
           ;
    
END//
DELIMITER ;


-- 프로시저 my_test_db.logwrite 구조 내보내기
DROP PROCEDURE IF EXISTS `logwrite`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `logwrite`(IN `p_log` TEXT)
    COMMENT '디버깅용 로그 저장'
BEGIN

    ## 새로운 번호를 부쳐
    SELECT IFNULL(MAX(SEQ),0)+1 INTO @NEW_SEQ 
      FROM tmp_log
           ;

   ## 추가
   INSERT INTO tmp_log 
               (seq,log_datetime,log_text) 
        VALUES (@NEW_SEQ,NOW(),p_log)
               ;
                     
END//
DELIMITER ;


-- 프로시저 my_test_db.split_tags_into_rows 구조 내보내기
DROP PROCEDURE IF EXISTS `split_tags_into_rows`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `split_tags_into_rows`(IN _in_tags_to_be_seperated VARCHAR(8000), IN _in_seperator CHAR(3))
proc_main:BEGIN -- 1. Begin Proc

DECLARE v_keyword VARCHAR(255);
DECLARE v_keyword_id MEDIUMINT UNSIGNED;

-- Iteration variable (v_tags_done: if done through each and every work of input string paramter, 
--       v_tags_idx: currently running id )
DECLARE v_tags_done TINYINT UNSIGNED;
DECLARE v_tags_idx INT UNSIGNED;

-- Temporary Table Declaration & initialization (as DB doesn't support array, we've to split the incoming tag based and put each and
-- every "tag" into temporary table, MAKE SURE TO DROP IT BEFORE LEAVING THE PROC)
-- drop temporary table
DROP TEMPORARY TABLE IF EXISTS temp_token_to_delete;

--  create temporary table
CREATE TEMPORARY TABLE temp_token_to_delete (Id INT NOT NULL PRIMARY KEY AUTO_INCREMENT, Word VARCHAR(256));

-- 
SET autocommit = 0; 

  -- split the out the _in_tags_to_be_seperated and insert into temporary table
  SET v_tags_done = 0;       
  SET v_tags_idx = 1;

  WHILE NOT v_tags_done DO -- 1.BEGIN WHILE  
    -- get the word from "," to "," 
    SET v_keyword = SUBSTRING(_in_tags_to_be_seperated, v_tags_idx, 
      IF(LOCATE(_in_seperator, _in_tags_to_be_seperated, v_tags_idx) > 0, 
        LOCATE(_in_seperator, _in_tags_to_be_seperated, v_tags_idx) - v_tags_idx, 
        LENGTH(_in_tags_to_be_seperated))
        );

      IF LENGTH(v_keyword) > 0 THEN

        SET v_tags_idx = v_tags_idx + LENGTH(v_keyword) + 1;

        SET v_keyword = TRIM(v_keyword);

        -- add the keyword into temporary table
        INSERT IGNORE INTO temp_token_to_delete (Word) VALUES (v_keyword);

      ELSE
        SET v_tags_done = 1;
      END IF;

  END WHILE; -- 1.END WHILE  

COMMIT;

-- Select records 
SELECT Id, Word FROM temp_token_to_delete;

-- Clean your DB: drop temporary table (it should be last statement
--                                      , if you want to use the data of temporary table in between the proc)
DROP TEMPORARY TABLE IF EXISTS temp_token_to_delete;

END proc_main//
DELIMITER ;


-- 프로시저 my_test_db.SP_BAS_AFFILIATE_SEL 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_BAS_AFFILIATE_SEL`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_BAS_AFFILIATE_SEL`()
    COMMENT '계열사 리스트를 구한다.'
BEGIN

	SELECT SEQ
          ,AFFILIATE_NM	
      FROM bas_affiliate
     WHERE SEQ > 0
           ;     
           
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_BAS_CONTACT_SEL 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_BAS_CONTACT_SEL`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_BAS_CONTACT_SEL`()
    COMMENT '연락처 구분 리스트를 구한다.'
BEGIN

    SELECT CODE
          ,CONTACT_NM
      FROM bas_contact
  ORDER BY ORDER_NO
           ;
           
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_BAS_DISTRIBUTOR_SEL 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_BAS_DISTRIBUTOR_SEL`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_BAS_DISTRIBUTOR_SEL`()
    COMMENT '배급사 리스트를 구한다.'
BEGIN

	SELECT SEQ
          ,DISTRIBUTOR_NM	
      FROM bas_distributor
           ;     
           
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_BAS_GENRE_SEL 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_BAS_GENRE_SEL`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_BAS_GENRE_SEL`()
    COMMENT '장르 리스트를 구한다.'
BEGIN

	SELECT SEQ
          ,GENRE_NM	
      FROM bas_genre
           ;     
           
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_BAS_GRADE_SEL 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_BAS_GRADE_SEL`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_BAS_GRADE_SEL`()
    COMMENT '관람등급 리스트를 구한다.'
BEGIN

    SELECT SEQ
          ,GRADE_NM 
      FROM bas_grade
           ;
           
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_BAS_ISDIRECT_SEL 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_BAS_ISDIRECT_SEL`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_BAS_ISDIRECT_SEL`()
    COMMENT '직영/위탁 리스트를 구한다.'
BEGIN

    SELECT CODE
          ,DIRECT_NM 
      FROM bas_isdirect
     WHERE CODE <> ''
           ;
           
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_BAS_KORABD_GBN_SEL 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_BAS_KORABD_GBN_SEL`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_BAS_KORABD_GBN_SEL`()
    COMMENT '방화/외화 구분 리스트를 구한다.'
BEGIN

    SELECT CODE
          ,GBN_NM
      FROM bas_korabd_gbn      
           ;    
           
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_BAS_LOCATION_SEL_CHILD 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_BAS_LOCATION_SEL_CHILD`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_BAS_LOCATION_SEL_CHILD`(IN `P_PARENT_SEQ` INT UNSIGNED)
    NO SQL
    COMMENT '상위아래 하위지역들의 리스트를 구한다'
BEGIN

	SELECT SEQ
          ,LOCATION_NM 
      FROM bas_location
     WHERE PARENT_SEQ = P_PARENT_SEQ
       AND SEQ > 0 
           ;
                
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_BAS_LOCATION_SEL_CHILD_ALL 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_BAS_LOCATION_SEL_CHILD_ALL`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_BAS_LOCATION_SEL_CHILD_ALL`()
    COMMENT '하위지역리스트 전체'
BEGIN

	SELECT SEQ
          ,LOCATION_NM 
          ,PARENT_SEQ
      FROM bas_location
     WHERE PARENT_SEQ > 0
       AND SEQ > 0 
           ;     
           
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_BAS_LOCATION_SEL_PARENT 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_BAS_LOCATION_SEL_PARENT`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_BAS_LOCATION_SEL_PARENT`()
    NO SQL
    COMMENT '상위지역들의 리스트를 구한다'
BEGIN

    SELECT SEQ
          ,LOCATION_NM 
      FROM bas_location
     WHERE PARENT_SEQ = 0
       AND SEQ > 0
           ;
   
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_BAS_PLAYPRINT1_SEL 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_BAS_PLAYPRINT1_SEL`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_BAS_PLAYPRINT1_SEL`()
    COMMENT '상영 프린트1 리스트를 구한다.'
BEGIN

	SELECT SEQ
          ,PLAY_PRINT_NM	
      FROM bas_playprint1
           ;     
           
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_BAS_PLAYPRINT2_SEL 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_BAS_PLAYPRINT2_SEL`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_BAS_PLAYPRINT2_SEL`()
    COMMENT '상영 프린트2 리스트를 구한다.'
BEGIN

	SELECT SEQ
          ,PLAY_PRINT_NM	
      FROM bas_playprint2
           ;     
           
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_BAS_POSTZIP_SEL_COUNT 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_BAS_POSTZIP_SEL_COUNT`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_BAS_POSTZIP_SEL_COUNT`(IN `P_DONG_NM` VARCHAR(40))
    COMMENT '신 우편번호리스트의 갯수를 구한다.'
BEGIN

    SELECT COUNT(*)
      FROM bas_postzip
     WHERE DONG_NM LIKE  CONCAT(P_DONG_NM COLLATE utf8_unicode_ci,'%') 
           ;
           
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_BAS_POSTZIP_SEL_PAGE 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_BAS_POSTZIP_SEL_PAGE`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_BAS_POSTZIP_SEL_PAGE`(IN `P_DONG_NM` VARCHAR(40), IN `P_PAGENO` INT UNSIGNED, IN `P_LISTCOUNT` INT UNSIGNED)
    COMMENT '신 우편번호 리스트를 페이지 단위로 구한다.'
BEGIN
      DECLARE START INT ;
      
      SET START = (P_PAGENO - 1) * P_LISTCOUNT ;

      SELECT CODE             
            ,SI_DO_K            
            ,SI_DO_E            
            ,KUN_KU_K           
            ,KUN_KU_E           
            ,UB_MYUN_K          
            ,UB_MYUN_E          
            ,ROAD_CD            
            ,ROAD_NM_K          
            ,ROAD_NM_E          
            ,UNDER              
            ,BUILDNO_BUN1       
            ,BUILDNO_BUN2       
            ,BUILDNO_MNG        
            ,DELIVERY_LOC       
            ,BUILDING_NM        
            ,BJD_CD             
            ,BJD_NM             
            ,LEE_NM             
            ,DONG_NM            
            ,MOUNTAIN           
            ,JIBUN1             
            ,UB_MYUN_DONG_SEQ   
            ,JIBUN2             
        FROM bas_postzip
       WHERE DONG_NM LIKE  CONCAT(P_DONG_NM COLLATE utf8_unicode_ci,'%') 
    ORDER BY SI_DO_K
            ,KUN_KU_K
            ,BJD_CD
       LIMIT START,P_LISTCOUNT
             ;   
             
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_BAS_PREMIUM_RATE_INITI 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_BAS_PREMIUM_RATE_INITI`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_BAS_PREMIUM_RATE_INITI`()
    COMMENT '부율정보 초기화(없으면 50%로,다면 건너뛴다,)'
BLOCK1 : BEGIN
          
    DECLARE NO_MORE_ROWS BOOLEAN DEFAULT FALSE;
          
    DECLARE V_KORABD_GBN_CODE VARCHAR(1) ;
    DECLARE V_LOCATION_SEQ NUMERIC ;
    DECLARE V_AFFILIATE_SEQ NUMERIC ;
    DECLARE V_ISDIRECT_CODE VARCHAR(1) ;
    DECLARE V_UNAFFILIATE_SEQ NUMERIC ;
          
    DECLARE V_CURSOR
     CURSOR FOR 
            SELECT *
             FROM (
                      SELECT KAG.CODE  KORABD_GBN_CODE
                                      ,LOC.SEQ   LOCATION_SEQ
                                      ,AF.SEQ    AFFILIATE_SEQ
                                      ,ID.CODE   ISDIRECT_CODE
                                      ,0         UNAFFILIATE_SEQ
                                  FROM bas_korabd_gbn KAG                
                                      ,bas_location   LOC
                                      ,bas_affiliate  AF
                                      ,bas_isdirect   ID
                                 WHERE LOC.PARENT_SEQ > 0
                                   AND AF.SEQ  > 0
                                   AND ID.CODE <> ''
                    UNION ALL
                      SELECT KAG.CODE  KORABD_GBN_CODE
                                      ,LOC.SEQ   LOCATION_SEQ
                                      ,0         AFFILIATE_SEQ
                                      ,''      ISDIRECT_CODE
                                      ,UAF.SEQ   UNAFFILIATE_SEQ
                                  FROM bas_korabd_gbn  KAG                
                                      ,bas_location    LOC
                                      ,bas_unaffiliate UAF
                                 WHERE LOC.PARENT_SEQ > 0
                                   AND UAF.SEQ  > 0
                  ) RATE
         ORDER BY KORABD_GBN_CODE         
                 ,LOCATION_SEQ
                 ,AFFILIATE_SEQ IS NULL, AFFILIATE_SEQ 
                 ,ISDIRECT_CODE IS NULL, ISDIRECT_CODE DESC
                 ,UNAFFILIATE_SEQ
                  ;                  
          
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET NO_MORE_ROWS = TRUE;
          
    OPEN V_CURSOR ;
          
    V_LOOP : LOOP
          
        FETCH V_CURSOR INTO V_KORABD_GBN_CODE,V_LOCATION_SEQ,V_AFFILIATE_SEQ,V_ISDIRECT_CODE,V_UNAFFILIATE_SEQ ;

          
        IF NO_MORE_ROWS THEN
        
            LEAVE V_LOOP;
            
        ELSE
        
            IF V_UNAFFILIATE_SEQ = 0 THEN        
                    SELECT COUNT(*) INTO @V_COUNT
                      FROM bas_premium_rate
                     WHERE KORABD_GBN_CODE = V_KORABD_GBN_CODE  COLLATE UTF8_UNICODE_CI 
                       AND LOCATION_SEQ    = V_LOCATION_SEQ 
                       AND AFFILIATE_SEQ   = V_AFFILIATE_SEQ 
                       AND ISDIRECT_CODE   = V_ISDIRECT_CODE  COLLATE UTF8_UNICODE_CI 
                           ;
            END IF ;       
                
            IF V_AFFILIATE_SEQ = 0 AND V_ISDIRECT_CODE = '' THEN        
                    SELECT COUNT(*) INTO @V_COUNT
                      FROM bas_premium_rate
                     WHERE KORABD_GBN_CODE = V_KORABD_GBN_CODE  COLLATE UTF8_UNICODE_CI 
                       AND LOCATION_SEQ    = V_LOCATION_SEQ 
                       AND UNAFFILIATE_SEQ = V_UNAFFILIATE_SEQ
                           ;
            END IF ;       
                

            IF @V_COUNT = 0 THEN   
                    SELECT IFNULL(MAX(SEQ),0)+1 INTO @NEWSEQ FROM bas_premium_rate;
    
                    INSERT INTO bas_premium_rate
                                (SEQ
                                ,KORABD_GBN_CODE
                                ,LOCATION_SEQ
                                ,AFFILIATE_SEQ
                                ,ISDIRECT_CODE
                                ,UNAFFILIATE_SEQ
                                ,PREMIUM_RATE
                                ) 
                         VALUES (@NEWSEQ
                                ,V_KORABD_GBN_CODE
                                ,V_LOCATION_SEQ
                                ,V_AFFILIATE_SEQ
                                ,V_ISDIRECT_CODE
                                ,V_UNAFFILIATE_SEQ
                                ,50.0
                                )
                                ;
            END IF;
        END IF;
          
          
    END LOOP V_LOOP ;   
          
          
    CLOSE V_CURSOR ;
          
END BLOCK1//
DELIMITER ;


-- 프로시저 my_test_db.SP_BAS_PREMIUM_RATE_SAVE 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_BAS_PREMIUM_RATE_SAVE`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_BAS_PREMIUM_RATE_SAVE`(IN `P_KORABD_GBN` VARCHAR(1), IN `P_VALUES` TEXT, IN `P_SEPAR` VARCHAR(1))
    COMMENT '부율 하나를 갱신또는 추가한다.'
BEGIN 

    DECLARE V_KEYWORD    VARCHAR(255);
    DECLARE V_KEYWORD_ID MEDIUMINT UNSIGNED;
    
    DECLARE V_TAGS_DONE TINYINT UNSIGNED;
    DECLARE V_TAGS_IDX INT UNSIGNED;
    
    
    DECLARE V_VAR    VARCHAR(20);
    DECLARE V_VAL    VARCHAR(10);
    
    DECLARE V_VAR_LOC        VARCHAR(3);
    DECLARE V_VAR_AFFILIAT   VARCHAR(2);
    DECLARE V_VAR_ISDIRECT   VARCHAR(1);
    DECLARE V_VAR_UNAFFILIAT VARCHAR(2);

    SET V_TAGS_DONE = 0;       
    SET V_TAGS_IDX = 1;
    
    SET @CNT = 0 ;
    
    WHILE NOT V_TAGS_DONE DO
        
        SET V_KEYWORD = SUBSTRING(P_VALUES
                                 ,V_TAGS_IDX
                                 ,IF(LOCATE(P_SEPAR, P_VALUES, V_TAGS_IDX) > 0, LOCATE(P_SEPAR, P_VALUES, V_TAGS_IDX) - V_TAGS_IDX, LENGTH(P_VALUES))      
                                 );
    
          IF LENGTH(V_KEYWORD) > 0 THEN
    
            SET V_TAGS_IDX = V_TAGS_IDX + LENGTH(V_KEYWORD) + 1;
            SET V_KEYWORD = TRIM(V_KEYWORD);
            
            SET V_VAR = FN_SPLIT_STRING(V_KEYWORD,'=',1) ;
            SET V_VAL = FN_SPLIT_STRING(V_KEYWORD,'=',2) ;


            SET V_VAR_LOC        = FN_SPLIT_STRING(V_VAR,'_',2) ;
            SET V_VAR_AFFILIAT   = FN_SPLIT_STRING(V_VAR,'_',3) ;
            SET V_VAR_ISDIRECT   = FN_SPLIT_STRING(V_VAR,'_',4) ;
            SET V_VAR_UNAFFILIAT = FN_SPLIT_STRING(V_VAR,'_',5) ;
            
            
            
            IF  (V_VAR_AFFILIAT!="") AND (V_VAR_ISDIRECT!="") THEN            
            
                
                SELECT COUNT(*) INTO @CNT       
                  FROM bas_premium_rate
                 WHERE KORABD_GBN_CODE = P_KORABD_GBN
                   AND LOCATION_SEQ    = V_VAR_LOC
                   AND AFFILIATE_SEQ   = CAST(V_VAR_AFFILIAT AS UNSIGNED INTEGER)
                   AND ISDIRECT_CODE   = V_VAR_ISDIRECT;
                 
                IF  (@CNT>0) THEN
                  
                    UPDATE bas_premium_rate                
                       SET PREMIUM_RATE = V_VAL  
                     WHERE KORABD_GBN_CODE = P_KORABD_GBN
                       AND LOCATION_SEQ    = V_VAR_LOC
                       AND AFFILIATE_SEQ   = V_VAR_AFFILIAT
                       AND ISDIRECT_CODE   = V_VAR_ISDIRECT;
                       
                ELSE 
                    
                    SELECT IFNULL(MAX(SEQ),0)+1 INTO @NEWSEQ FROM bas_premium_rate;
                
                    INSERT INTO bas_premium_rate
                               (
                                SEQ
                                ,KORABD_GBN_CODE
                                ,LOCATION_SEQ
                                ,AFFILIATE_SEQ
                                ,ISDIRECT_CODE
                                ,PREMIUM_RATE
                               ) 
                          VALUES
                                (
                                 @NEWSEQ
                                 ,P_KORABD_GBN
                                 ,V_VAR_LOC
                                 ,V_VAR_AFFILIAT
                                 ,V_VAR_ISDIRECT
                                 ,V_VAL
                                ) ;
                END IF;            
                  
            END IF;
    
            IF  (V_VAR_UNAFFILIAT!="") THEN            
            
                SELECT COUNT(*) INTO @CNT       
                  FROM bas_premium_rate
                 WHERE KORABD_GBN_CODE = P_KORABD_GBN
                   AND LOCATION_SEQ    = V_VAR_LOC
                   AND UNAFFILIATE_SEQ = CAST(V_VAR_UNAFFILIAT AS UNSIGNED INTEGER) ;
                 
                IF  (@CNT>0) THEN
                  
                    UPDATE bas_premium_rate                
                       SET PREMIUM_RATE = V_VAL  
                     WHERE KORABD_GBN_CODE = P_KORABD_GBN
                       AND LOCATION_SEQ    = V_VAR_LOC
                       AND UNAFFILIATE_SEQ = V_VAR_UNAFFILIAT ;
                       
                ELSE 
                    SELECT IFNULL(MAX(SEQ),0)+1 INTO @NEWSEQ FROM bas_premium_rate;
                
                    INSERT INTO bas_premium_rate
                               (
                                SEQ
                                ,KORABD_GBN_CODE
                                ,LOCATION_SEQ
                                ,UNAFFILIATE_SEQ
                                ,PREMIUM_RATE
                               ) 
                          VALUES
                                (
                                 @NEWSEQ
                                 ,P_KORABD_GBN
                                 ,V_VAR_LOC
                                 ,V_VAR_UNAFFILIAT
                                 ,V_VAL
                                ) ;
                END IF;            
                  
            END IF;
    
          ELSE
            SET V_TAGS_DONE = 1;
          END IF;
    
    END WHILE;       
      
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_BAS_PREMIUM_RATE_SEL 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_BAS_PREMIUM_RATE_SEL`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_BAS_PREMIUM_RATE_SEL`(IN `P_KORABD_GBN` VARCHAR(1))
    COMMENT '방화/외화별 기본 부율값'
BEGIN
    
        SELECT BASE.*
              ,P.PREMIUM_RATE
          FROM (           
                    SELECT * 
                      FROM (
                             SELECT FLOOR(A.SEQ)   A_SEQ      
                                   ,A.AFFILIATE_NM A_AFFILIATE_NM             
                                   ,ID.CODE        ID_CODE      
                                   ,ID.DIRECT_NM   ID_DIRECT_NM               
                                   ,NULL           UA_SEQ    
                                   ,NULL           UA_UNAFFILIATE_NM   
                                   ,ID.DIRECT_NM   ETC_TEXT               
                               FROM bas_affiliate A
                                   ,bas_isdirect ID
                           ) A 
                           ,(   
                                SELECT ZONE.SEQ ZONE_SEQ
                                      ,ZONE.LOCATION_NM ZONE_LOCATION_NM
                                      ,DETAIL.SEQ DETAIL_SEQ
                                      ,DETAIL.LOCATION_NM DETAIL_LOCATION_NM
                                  FROM (
                                         SELECT * 
                                           FROM bas_location     
                                          WHERE PARENT_SEQ = 0
                                       ) ZONE
                             LEFT JOIN (
                                         SELECT * 
                                           FROM bas_location     
                                          WHERE PARENT_SEQ <> 0   
                                       ) DETAIL       
                                    ON ZONE.SEQ = DETAIL.PARENT_SEQ
                          ) B
                 ORDER BY A.A_SEQ IS NULL ,A.A_SEQ
                         ,A.ID_CODE IS NULL ,A.ID_CODE DESC
                         ,A.UA_SEQ   
                         ,B.ZONE_SEQ
                         ,B.DETAIL_SEQ
               ) BASE   
     LEFT JOIN bas_premium_rate P
            ON P.KORABD_GBN_CODE = P_KORABD_GBN COLLATE utf8_unicode_ci 
           AND P.LOCATION_SEQ = BASE.DETAIL_SEQ
           AND P.AFFILIATE_SEQ = BASE.A_SEQ
           AND P.ISDIRECT_CODE = BASE.ID_CODE                    
                
        UNION ALL    
        
        SELECT BASE.*
              ,P.PREMIUM_RATE
          FROM (           
                     SELECT * 
                       FROM (
                              SELECT NULL               A_SEQ      
                                    ,NULL               A_AFFILIATE_NM             
                                    ,NULL               ID_CODE      
                                    ,NULL               ID_DIRECT_NM               
                                    ,FLOOR(UA.SEQ)      UA_SEQ                  
                                    ,UA.UNAFFILIATE_NM  UA_UNAFFILIATE_NM  
                                    ,UA.UNAFFILIATE_NM  ETC_TEXT                                          
                                FROM bas_unaffiliate UA
                            ) A 
                            ,(   
                                 SELECT ZONE.SEQ ZONE_SEQ
                                       ,ZONE.LOCATION_NM ZONE_LOCATION_NM
                                       ,DETAIL.SEQ DETAIL_SEQ
                                       ,DETAIL.LOCATION_NM DETAIL_LOCATION_NM
                                   FROM (
                                          SELECT * 
                                            FROM bas_location     
                                           WHERE PARENT_SEQ = 0
                                        ) ZONE
                              LEFT JOIN (
                                         SELECT * 
                                           FROM bas_location     
                                         WHERE PARENT_SEQ <> 0   
                                        ) DETAIL       
                                     ON ZONE.SEQ = DETAIL.PARENT_SEQ
                            ) B
                   ORDER BY A.A_SEQ IS NULL ,A.A_SEQ
                           ,A.ID_CODE IS NULL ,A.ID_CODE DESC
                           ,A.UA_SEQ   
                           ,B.ZONE_SEQ
                           ,B.DETAIL_SEQ
               ) BASE   
     LEFT JOIN bas_premium_rate P
            ON P.KORABD_GBN_CODE  = P_KORABD_GBN COLLATE utf8_unicode_ci 
           AND P.LOCATION_SEQ    = BASE.DETAIL_SEQ            
           AND P.UNAFFILIATE_SEQ = BASE.UA_SEQ                
      ORDER BY A_SEQ IS NULL,A_SEQ
              ,ID_CODE ASC
              ,UA_SEQ ASC
              ,ZONE_SEQ 
              ,DETAIL_SEQ                             
               ;

END//
DELIMITER ;


-- 프로시저 my_test_db.SP_BAS_UNAFFILIATE_SEL 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_BAS_UNAFFILIATE_SEL`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_BAS_UNAFFILIATE_SEL`()
    COMMENT '비계열 리스트를 구한다.'
BEGIN

	SELECT SEQ
          ,UNAFFILIATE_NM	
      FROM bas_unaffiliate
     WHERE SEQ > 0 
           ;     
           
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_BAS_USER_GROUP_SEL 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_BAS_USER_GROUP_SEL`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_BAS_USER_GROUP_SEL`()
    COMMENT '사용자그룹 리스트를 구한다.'
BEGIN

    SELECT SEQ
          ,USER_GROUP_NM 
      FROM bas_user_group
     WHERE SEQ > 0  
           ;
           
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_BAS_ZIP_SEL 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_BAS_ZIP_SEL`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_BAS_ZIP_SEL`()
    NO SQL
    COMMENT '우편번호 리스트를 보여준다.'
BEGIN

      SELECT ZIP_CODE
            ,ZIP_SEQ
            ,SI_DO
            ,KUN_KU
            ,UB_MYUN_DONG
            ,S_BUNJI1
            ,S_BUNJI2
            ,LOCATION
            ,S_DONG
            ,E_DONG
        FROM bas_zip
             ;
             
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_BAS_ZIP_SEL_COUNT 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_BAS_ZIP_SEL_COUNT`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_BAS_ZIP_SEL_COUNT`()
    NO SQL
    COMMENT '우편번호 리스트의 갯수를 구한다.'
BEGIN

	SELECT COUNT(*)
      FROM bas_zip
           ;
     
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_BAS_ZIP_SEL_PAGE 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_BAS_ZIP_SEL_PAGE`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_BAS_ZIP_SEL_PAGE`(IN `P_PAGENO` INT UNSIGNED, IN `P_LISTCOUNT` INT UNSIGNED)
    NO SQL
    COMMENT '우편번호 리스트를 페이지별로 구한다.'
BEGIN

      DECLARE START INT ;
      
      SET START = (P_PAGENO - 1) * P_LISTCOUNT ;

      SELECT ZIP_CODE
            ,ZIP_SEQ
            ,SI_DO
            ,KUN_KU
            ,UB_MYUN_DONG
            ,S_BUNJI1
            ,S_BUNJI2
            ,LOCATION
            ,S_DONG
            ,E_DONG
        FROM bas_zip
       LIMIT START,P_LISTCOUNT
             ;
             
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_LST_AFFILIATE_DIR_SEL 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_LST_AFFILIATE_DIR_SEL`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LST_AFFILIATE_DIR_SEL`()
    COMMENT '계열사 리스트'
BEGIN

    SELECT A.SEQ          A_SEQ      
          ,A.AFFILIATE_NM A_AFFILIATE_NM             
          ,ID.CODE        ID_CODE      
          ,ID.DIRECT_NM   ID_DIRECT_NM               
      FROM bas_affiliate A
          ,bas_isdirect ID
     WHERE A.SEQ > 0 
       AND ID.CODE IS NOT NULL    
       AND ID.CODE <> ''
           ;
           
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_LST_LOCATIONCHILD_SEL 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_LST_LOCATIONCHILD_SEL`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LST_LOCATIONCHILD_SEL`()
    COMMENT '하위지역 리스트'
BEGIN

   SELECT SEQ
          ,LOCATION_NM 
      FROM bas_location
     WHERE PARENT_SEQ > 0
       AND SEQ > 0
           ;
     
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_LST_PREMIUM_RATE_BY_AFFILIATE_SEL 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_LST_PREMIUM_RATE_BY_AFFILIATE_SEL`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LST_PREMIUM_RATE_BY_AFFILIATE_SEL`(IN `P_KORABD_GBN_CODE` VARCHAR(1), IN `P_AFFILIATE_SEQ` INT UNSIGNED, IN `P_ISDIRECT_CODE` VARCHAR(1))
    COMMENT '계열사별 부율구하기'
BEGIN

        SELECT LOC.SEQ
              ,LOC.LOCATION_NM
              ,PR.PREMIUM_RATE 
          FROM bas_location LOC
     LEFT JOIN (
                SELECT LOCATION_SEQ
                      ,PREMIUM_RATE
                  FROM bas_premium_rate
                 WHERE KORABD_GBN_CODE = P_KORABD_GBN_CODE COLLATE utf8_unicode_ci 
                   AND AFFILIATE_SEQ = P_AFFILIATE_SEQ
                   AND ISDIRECT_CODE = P_ISDIRECT_CODE COLLATE utf8_unicode_ci 
               ) PR
            ON LOC.SEQ = PR.LOCATION_SEQ
         WHERE LOC.PARENT_SEQ <> 0    
      ORDER BY LOC.SEQ
               ;

END//
DELIMITER ;


-- 프로시저 my_test_db.SP_LST_PREMIUM_RATE_BY_UNAFFILIATE_SEL 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_LST_PREMIUM_RATE_BY_UNAFFILIATE_SEL`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LST_PREMIUM_RATE_BY_UNAFFILIATE_SEL`(IN `P_KORABD_GBN_CODE` VARCHAR(1), IN `P_UNAFFILIATE_SEQ` INT  UNSIGNED)
    COMMENT '비계열사별 부율구하기'
BEGIN

        SELECT LOC.SEQ
              ,LOC.LOCATION_NM
              ,PR.PREMIUM_RATE 
          FROM bas_location LOC
     LEFT JOIN (
                SELECT LOCATION_SEQ
                      ,PREMIUM_RATE
                  FROM bas_premium_rate
                 WHERE KORABD_GBN_CODE = P_KORABD_GBN_CODE COLLATE utf8_unicode_ci 
                   AND UNAFFILIATE_SEQ = P_UNAFFILIATE_SEQ
               ) PR
            ON LOC.SEQ = PR.LOCATION_SEQ
         WHERE LOC.PARENT_SEQ <> 0    
      ORDER BY LOC.SEQ
               ;
       
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_LST_UNAFFILIATE_SEL 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_LST_UNAFFILIATE_SEL`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LST_UNAFFILIATE_SEL`()
    COMMENT '비계열사 리스트'
BEGIN

       SELECT UA.SEQ             
             ,UA.UNAFFILIATE_NM  
         FROM bas_unaffiliate UA
        WHERE UA.SEQ >0
              ;
              
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_WRK_CONTACT_SEL 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_WRK_CONTACT_SEL`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_WRK_CONTACT_SEL`(IN `P_THEATER_CODE` VARCHAR(6), IN `P_GBN_CODE` VARCHAR(1))
    COMMENT '연락처 리스트를 구한다.'
BEGIN

    SELECT SEQ
          ,NAME
          ,TEL
          ,HP
          ,FAX
          ,MAIL
      FROM wrk_contact
     WHERE THEATER_CODE = P_THEATER_CODE COLLATE utf8_unicode_ci 
       AND GBN_CODE = P_GBN_CODE  COLLATE utf8_unicode_ci 
           ;

END//
DELIMITER ;


-- 프로시저 my_test_db.SP_WRK_FILM_DELETE 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_WRK_FILM_DELETE`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_WRK_FILM_DELETE`(IN `P_CODE` VARCHAR(8))
    COMMENT '영화정보 삭제처리'
BEGIN
    
    UPDATE wrk_film
       SET DEL_FLAG = 'Y'
     WHERE CODE = P_CODE COLLATE utf8_unicode_ci 
           ;
           
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_WRK_FILM_SEL_COUNT 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_WRK_FILM_SEL_COUNT`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_WRK_FILM_SEL_COUNT`()
    COMMENT '영화리스트의 총레코드 수를 구한다.'
BEGIN

    SELECT COUNT(*)
      FROM wrk_film
           ;
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_WRK_FILM_SEL_PAGE 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_WRK_FILM_SEL_PAGE`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_WRK_FILM_SEL_PAGE`(IN `P_PAGENO` INT  UNSIGNED, IN `P_LISTCOUNT` INT  UNSIGNED)
    COMMENT '영화정보리스트를 페이지 단위로 구한다.'
BEGIN

      DECLARE START INT ;
      
      SET START = (P_PAGENO - 1) * P_LISTCOUNT ;

      SELECT CODE             
            ,DISTRIBUTOR      
            ,FILM_NM          
            ,GRADE            
            ,FIRST_PLAY_DT    
            ,OPEN_DT          
            ,CLOSE_DT         
            ,REOPEM_DT        
            ,RECLOSE_DT       
            ,POSTER_YN        
            ,IMAGES_NO        
            ,DEL_FLAG         
        FROM wrk_film
       LIMIT START, P_LISTCOUNT
             ;
             
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_WRK_PLAYPRINT_SEL 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_WRK_PLAYPRINT_SEL`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_WRK_PLAYPRINT_SEL`(IN `P_FILM_CODE` VARCHAR(8))
    COMMENT '상영프린트정보 리스트를 구한다.'
BEGIN

      SELECT PP.SEQ                        
            ,FILM_CODE                     
            ,P1.PLAY_PRINT_NM  PLAYPRINT1  
            ,P2.PLAY_PRINT_NM  PLAYPRINT2  
            ,PP.MEMO                       
        FROM wrk_playprint PP
  INNER JOIN bas_playprint1 P1
          ON PP.PLAYPRINT1_SEQ = P1.SEQ
  INNER JOIN bas_playprint2 P2
          ON PP.PLAYPRINT2_SEQ = P2.SEQ      
       WHERE FILM_CODE = P_FILM_CODE  COLLATE utf8_unicode_ci 
             ;

END//
DELIMITER ;


-- 프로시저 my_test_db.SP_WRK_PLAYPRINT_SEL_COUNT 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_WRK_PLAYPRINT_SEL_COUNT`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_WRK_PLAYPRINT_SEL_COUNT`(IN `P_FILM_CODE` VARCHAR(8))
    COMMENT '영화정보내 상영프린트 리스트의 갯수를 구한다.'
BEGIN

   SELECT COUNT(*)
     FROM wrk_playprint
    WHERE FILM_CODE = P_FILM_CODE  COLLATE utf8_unicode_ci 
          ;
          
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_WRK_PLAYPRINT_SEL_PAGE 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_WRK_PLAYPRINT_SEL_PAGE`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_WRK_PLAYPRINT_SEL_PAGE`(IN `P_FILM_CODE` VARCHAR(8), IN `P_PAGENO` INT UNSIGNED, IN `P_LISTCOUNT` INT UNSIGNED)
    COMMENT '영화정보내 상영프린터리스트를 페이지별로 구한다.'
BEGIN

      DECLARE START INT ;
      
      SET START = (P_PAGENO - 1) * P_LISTCOUNT ;

      SELECT PP.SEQ                        
            ,P1.PLAY_PRINT_NM  PLAYPRINT1  
            ,P2.PLAY_PRINT_NM  PLAYPRINT2  
            ,PP.MEMO                       
        FROM wrk_playprint PP
  INNER JOIN bas_playprint1 P1
          ON PP.PLAYPRINT1_SEQ = P1.SEQ
  INNER JOIN bas_playprint2 P2
          ON PP.PLAYPRINT2_SEQ = P2.SEQ      
       WHERE FILM_CODE = P_FILM_CODE  COLLATE utf8_unicode_ci 
       LIMIT START,P_LISTCOUNT
             ;
             
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_WRK_SHOWROOM_SEL 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_WRK_SHOWROOM_SEL`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_WRK_SHOWROOM_SEL`(IN `P_THEATER_CODE` VARCHAR(6))
    COMMENT '극장상영관 리스트를 구한다'
BEGIN

      SELECT SEQ              
            ,THEATER_CODE     
            ,ROOM_NM          
            ,ROOM_ALIAS       
            ,ART_ROOM         
            ,SEAT             
        FROM wrk_showroom
       WHERE THEATER_CODE = P_THEATER_CODE  COLLATE utf8_unicode_ci 
             ;
             
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_WRK_THEATER_CHGHIST_SEL_COUNT 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_WRK_THEATER_CHGHIST_SEL_COUNT`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_WRK_THEATER_CHGHIST_SEL_COUNT`(IN `P_THEATER_CODE` VARCHAR(6))
    COMMENT '극장변경 리스트의 갯수를 구한다.'
BEGIN

      SELECT COUNT(*)
        FROM wrk_theater_chghist
       WHERE THEATER_CODE = P_THEATER_CODE COLLATE utf8_unicode_ci 
      ;

END//
DELIMITER ;


-- 프로시저 my_test_db.SP_WRK_THEATER_CHGHIST_SEL_PAGE 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_WRK_THEATER_CHGHIST_SEL_PAGE`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_WRK_THEATER_CHGHIST_SEL_PAGE`(IN `P_THEATER_CODE` VARCHAR(6), IN `P_PAGENO` INT  UNSIGNED, IN `P_LISTCOUNT` INT  UNSIGNED)
    COMMENT '극장변경정보 리스트를 페이지 단위로 구한다'
BEGIN   

      DECLARE START INT ;
      
      SET START = (P_PAGENO - 1) * P_LISTCOUNT ;

         SELECT TR.SEQ              
               ,TR.GUBUN            
               ,TR.THEATER_CODE     
               ,TR.CHANGE_DATE      
               ,TR.CHANGE_TIME      
               ,LOC1.LOCATION_NM LOC1
               ,LOC2.LOCATION_NM LOC2
               ,AF.AFFILIATE_NM AFFILIATE_NM
               ,ID.DIRECT_NM
               ,UA.UNAFFILIATE_NM
               ,UG.USER_GROUP_NM
               ,TR.OPERATION       
               ,TR.THEATER_NM      
               ,TR.FUND_FREE       
               ,TR.GUBUN_CODE      
               ,TR.SAUP_NO         
               ,TR.OWNER           
               ,TR.SANGHO          
               ,TR.HOMEPAGE        
               ,TR.IMAGES_NO       
           FROM wrk_theater_chghist TR
      LEFT JOIN bas_location LOC1   
             ON TR.LOC1 = LOC1.SEQ
      LEFT JOIN bas_location LOC2   
             ON TR.LOC2 = LOC2.SEQ
      LEFT JOIN bas_affiliate AF
             ON TR.AFFILIATE_SEQ = AF.SEQ
      LEFT JOIN bas_isdirect ID
             ON TR.ISDIRECT = ID.CODE
      LEFT JOIN bas_unaffiliate UA
             ON TR.UNAFFILIATE_SEQ = UA.SEQ
      LEFT JOIN bas_user_group UG
             ON TR.UNAFFILIATE_SEQ = UG.SEQ
          WHERE TR.THEATER_CODE = P_THEATER_CODE  COLLATE utf8_unicode_ci 
       ORDER BY TR.SEQ DESC 
          LIMIT START,P_LISTCOUNT
                ;
             
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_WRK_THEATER_DELETE 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_WRK_THEATER_DELETE`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_WRK_THEATER_DELETE`(IN `P_CODE` VARCHAR(6))
    COMMENT '극장정보 하나를 삭제한다.'
BEGIN
    
    UPDATE wrk_theater
       SET OPERATION = 'N'
     WHERE CODE = P_CODE COLLATE utf8_unicode_ci 
           ;
     
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_WRK_THEATER_DISTRIBUTOR_SEL 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_WRK_THEATER_DISTRIBUTOR_SEL`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_WRK_THEATER_DISTRIBUTOR_SEL`(IN `P_THEATER_CODE` VARCHAR(6))
    COMMENT '극장의 배급사 리스트를 페이지 단위로 구한다'
BEGIN

      SELECT TD.SEQ
            ,TD.THEATER_CODE        
            ,DT.DISTRIBUTOR_NM DISTRIBUTOR_NM
            ,TD.THEATER_KNM         
            ,TD.THEATER_ENM         
            ,TD.THEATER_DCODE       
        FROM wrk_theater_distributor TD
   LEFT JOIN bas_distributor DT 
          ON TD.DISTRIBUTOR_SEQ = DT.SEQ
       WHERE THEATER_CODE = P_THEATER_CODE  COLLATE utf8_unicode_ci 
             ;
             
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_WRK_THEATER_SAVE 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_WRK_THEATER_SAVE`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_WRK_THEATER_SAVE`(IN `P_CODE` VARCHAR(6)      
    , IN `P_LOC1` DECIMAL(10,0)       
    , IN `P_LOC2` DECIMAL(10,0)       
    , IN `P_AFFILIATE_SEQ` DECIMAL(10,0)           
    , IN `P_ISDIRECT` VARCHAR(1)          
    , IN `P_UNAFFILIATE_SEQ` DECIMAL(10,0)           
    , IN `P_USER_GROUP_SEQ` DECIMAL(10,0)           
    , IN `P_OPEN_DT` DATE            
    , IN `P_THEATER_NM` VARCHAR(50)         
    , IN `P_ZIP` VARCHAR(6)          
    , IN `P_ADDR1` VARCHAR(20)         
    , IN `P_ADDR2` VARCHAR(20)         
    , IN `P_SCORE_TEL` VARCHAR(1)      
    , IN `P_SCORE_FAX` VARCHAR(1)      
    , IN `P_SCORE_MAIL` VARCHAR(1)      
    , IN `P_SCORE_SMS` VARCHAR(1)      
    , IN `P_PREMIUM_TEL` VARCHAR(1)      
    , IN `P_PREMIUM_FAX` VARCHAR(1)      
    , IN `P_PREMIUM_MAIL` VARCHAR(1)      
    , IN `P_PREMIUM_SMS` VARCHAR(1)      
    , IN `P_MEMO` TEXT            
    , IN `P_FUND_FREE` VARCHAR(1)      
    , IN `P_GUBUN_CODE` VARCHAR(30)         
    , IN `P_SAUP_NO` VARCHAR(12)         
    , IN `P_OWNER` VARCHAR(10)         
    , IN `P_SANGHO` VARCHAR(20)         
    , IN `P_HOMEPAGE` VARCHAR(30)         
    , IN `P_IMAGES_NO` INT(11) , IN `P_UNITPRICES` VARCHAR(200), OUT `P_NEW_CODE` VARCHAR(6), OUT `P_RESULT` INT)
    COMMENT '극장하나를 저장한다.'
BEGIN
    
    ##DECLARE V_NEW_CODE VARCHAR(6); ## 추가 등록시 새 코드를 부여 받는다.
    
    DECLARE EXIT HANDLER FOR SQLWARNING,NOT FOUND,SQLEXCEPTION   SET P_RESULT=-1; 
       

    IF  (P_CODE <> '') THEN ## 업데이트
    
        UPDATE wrk_theater 
           SET LOC1 = P_LOC1
              ,LOC2 = P_LOC2
              ,AFFILIATE_SEQ = P_AFFILIATE_SEQ
              ,ISDIRECT = P_ISDIRECT COLLATE utf8_unicode_ci 
              ,UNAFFILIATE_SEQ = P_UNAFFILIATE_SEQ
              ,USER_GROUP_SEQ = P_USER_GROUP_SEQ
              ,OPEN_DT = P_OPEN_DT
              ,THEATER_NM = P_THEATER_NM COLLATE utf8_unicode_ci 
              ,ZIP = P_ZIP COLLATE utf8_unicode_ci 
              ,ADDR1 = P_ADDR1 COLLATE utf8_unicode_ci 
              ,ADDR2 = P_ADDR2 COLLATE utf8_unicode_ci 
              ,SCORE_TEL = P_SCORE_TEL COLLATE utf8_unicode_ci 
              ,SCORE_FAX = P_SCORE_FAX COLLATE utf8_unicode_ci 
              ,SCORE_MAIL = P_SCORE_MAIL COLLATE utf8_unicode_ci 
              ,SCORE_SMS = P_SCORE_SMS COLLATE utf8_unicode_ci 
              ,PREMIUM_TEL = P_PREMIUM_TEL COLLATE utf8_unicode_ci 
              ,PREMIUM_FAX = P_PREMIUM_FAX COLLATE utf8_unicode_ci 
              ,PREMIUM_MAIL = P_PREMIUM_MAIL COLLATE utf8_unicode_ci 
              ,PREMIUM_SMS = P_PREMIUM_SMS COLLATE utf8_unicode_ci 
              ,MEMO = P_MEMO COLLATE utf8_unicode_ci 
              ,FUND_FREE = P_FUND_FREE COLLATE utf8_unicode_ci 
              ,GUBUN_CODE = P_GUBUN_CODE COLLATE utf8_unicode_ci 
              ,SAUP_NO = P_SAUP_NO COLLATE utf8_unicode_ci 
              ,OWNER = P_OWNER COLLATE utf8_unicode_ci 
              ,SANGHO = P_SANGHO COLLATE utf8_unicode_ci 
              ,HOMEPAGE = P_HOMEPAGE COLLATE utf8_unicode_ci 
              ,IMAGES_NO = P_IMAGES_NO
         WHERE CODE = P_CODE COLLATE utf8_unicode_ci  
               ;    
               
         IF (P_UNITPRICES <> '') THEN
             
             CALL SP_WRK_THEATER_UNITPRICE_SAVE(P_CODE COLLATE utf8_unicode_ci,P_UNITPRICES COLLATE utf8_unicode_ci,',') ;       
                 
         END IF;             
               
         SET P_RESULT = 1; ## 업데이트 성공
    
    ELSE  ## 인서트..
    
        SELECT FN_NEXT_THEATER() INTO P_NEW_CODE;  ## 새 코드..

        INSERT INTO wrk_theater
                  ( CODE
                   ,LOC1
                   ,LOC2
                   ,AFFILIATE_SEQ
                   ,ISDIRECT
                   ,UNAFFILIATE_SEQ
                   ,USER_GROUP_SEQ
                   ,OPEN_DT
                   ,OPERATION
                   ,THEATER_NM
                   ,ZIP
                   ,ADDR1
                   ,ADDR2
                   ,SCORE_TEL
                   ,SCORE_FAX
                   ,SCORE_MAIL
                   ,SCORE_SMS
                   ,PREMIUM_TEL
                   ,PREMIUM_FAX
                   ,PREMIUM_MAIL
                   ,PREMIUM_SMS
                   ,MEMO
                   ,FUND_FREE
                   ,GUBUN_CODE
                   ,SAUP_NO
                   ,OWNER
                   ,SANGHO
                   ,HOMEPAGE
                   ,IMAGES_NO
                  ) 
           VALUES ( P_NEW_CODE
                   ,P_LOC1
                   ,P_LOC2
                   ,P_AFFILIATE_SEQ
                   ,P_ISDIRECT COLLATE utf8_unicode_ci 
                   ,P_UNAFFILIATE_SEQ
                   ,P_USER_GROUP_SEQ
                   ,P_OPEN_DT
                   ,'Y'
                   ,P_THEATER_NM COLLATE utf8_unicode_ci 
                   ,P_ZIP COLLATE utf8_unicode_ci 
                   ,P_ADDR1 COLLATE utf8_unicode_ci 
                   ,P_ADDR2 COLLATE utf8_unicode_ci 
                   ,P_SCORE_TEL COLLATE utf8_unicode_ci 
                   ,P_SCORE_FAX COLLATE utf8_unicode_ci 
                   ,P_SCORE_MAIL COLLATE utf8_unicode_ci 
                   ,P_SCORE_SMS COLLATE utf8_unicode_ci 
                   ,P_PREMIUM_TEL COLLATE utf8_unicode_ci 
                   ,P_PREMIUM_FAX COLLATE utf8_unicode_ci 
                   ,P_PREMIUM_MAIL COLLATE utf8_unicode_ci 
                   ,P_PREMIUM_SMS COLLATE utf8_unicode_ci 
                   ,P_MEMO COLLATE utf8_unicode_ci 
                   ,P_FUND_FREE COLLATE utf8_unicode_ci 
                   ,P_GUBUN_CODE COLLATE utf8_unicode_ci 
                   ,P_SAUP_NO COLLATE utf8_unicode_ci 
                   ,P_OWNER COLLATE utf8_unicode_ci 
                   ,P_SANGHO COLLATE utf8_unicode_ci 
                   ,P_HOMEPAGE COLLATE utf8_unicode_ci 
                   ,P_IMAGES_NO
                  )
                  ;
                  
             IF (P_UNITPRICES <> '') THEN
             
                 CALL SP_WRK_THEATER_UNITPRICE_SAVE(P_NEW_CODE COLLATE utf8_unicode_ci,P_UNITPRICES COLLATE utf8_unicode_ci,',') ;       
                 
             END IF;
                  
             SET P_RESULT = 2;  ## 인서트 성공
   
    END IF;   
    
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_WRK_THEATER_SEL_COUNT 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_WRK_THEATER_SEL_COUNT`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_WRK_THEATER_SEL_COUNT`(IN `P_LOCATION1` INT UNSIGNED, IN `P_LOCATION2` INT UNSIGNED, IN `P_AFFILIATE_SEQ` INT UNSIGNED, IN `P_THEATER_NM` VARCHAR(50), IN `P_OPERATION` VARCHAR(1), IN `P_FUND_FREE` VARCHAR(1))
    COMMENT '극장정보의 레코드 갯수를 구한다.'
BEGIN

      SET @WHERE_STR = "";
      
      IF  (P_LOCATION1 != '')     THEN SET @WHERE_STR = CONCAT(@WHERE_STR,"\n  AND TR.LOC1 = ",P_LOCATION1); END IF;
      IF  (P_LOCATION2 != '')     THEN SET @WHERE_STR = CONCAT(@WHERE_STR,"\n  AND TR.LOC2 = ",P_LOCATION2); END IF;
      IF  (P_AFFILIATE_SEQ != '') THEN SET @WHERE_STR = CONCAT(@WHERE_STR,"\n  AND TR.AFFILIATE_SEQ = ",P_AFFILIATE_SEQ); END IF;
      IF  (P_THEATER_NM != '')    THEN SET @WHERE_STR = CONCAT(@WHERE_STR,"\n  AND TR.THEATER_NM LIKE '",P_THEATER_NM,"%' "); END IF;
      IF  (P_OPERATION != '')     THEN SET @WHERE_STR = CONCAT(@WHERE_STR,"\n  AND TR.OPERATION = 'Y' "); END IF;
      IF  (P_FUND_FREE != '')     THEN SET @WHERE_STR = CONCAT(@WHERE_STR,"\n  AND TR.FUND_FREE = '",P_FUND_FREE,"' "); END IF;

      SET @xSql = CONCAT("   SELECT COUNT(*)
                               FROM wrk_theater TR
                              WHERE 1=1
                         ",           
                         @WHERE_STR
                         ) ;
                         
       PREPARE stmt FROM @xSql;
       
       EXECUTE stmt ; 
       
       DEALLOCATE PREPARE stmt; ## prepare문을 해제한다.
          
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_WRK_THEATER_SEL_ONE 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_WRK_THEATER_SEL_ONE`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_WRK_THEATER_SEL_ONE`(IN `P_THEATER_CODE` VARCHAR(8))
    COMMENT '1개의 극장정보를 구한다.'
BEGIN

      SELECT CODE                ## 극장코드(TH0001)
            ,LOC1                ## 지역1
            ,LOC2                ## 지역2
            ,AFFILIATE_SEQ       ## 계열사코드
            ,ISDIRECT            ## Y:직영/N:위탁
            ,UNAFFILIATE_SEQ     ## 비계열코드
            ,USER_GROUP_SEQ      ## 사용자그룹코드
            ,OPEN_DT             ## 개관일
            ,OPERATION           ## 운영여부(Y:운영,N:폐관)
            ,THEATER_NM          ## 극장명
            ,ZIP                 ## 우편번호
            ,ADDR1               ## 주소1
            ,ADDR2               ## 주소2
            ,SCORE_TEL           ## 스코어 전화
            ,SCORE_FAX           ## 스코어 팩스
            ,SCORE_MAIL          ## 스코어 메일
            ,SCORE_SMS           ## 스코어 문자
            ,PREMIUM_TEL         ## 부금 전화
            ,PREMIUM_FAX         ## 부금 팩스
            ,PREMIUM_MAIL        ## 부금 메일
            ,PREMIUM_SMS         ## 부금 문자
            ,MEMO                ## 비고(극장특징)
            ,FUND_FREE           ## 기금면제여부
            ,GUBUN_CODE          ## 구분코드 ????
            ,SAUP_NO             ## 사업자등록번호
            ,OWNER               ## 대표자명
            ,SANGHO              ## 상호
            ,HOMEPAGE            ## 홈페이지
            ,IMAGES_NO           ## 이미지 첨부파일번호
        FROM wrk_theater 
       WHERE CODE = P_THEATER_CODE  COLLATE utf8_unicode_ci 
             ;
           
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_WRK_THEATER_SEL_PAGE 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_WRK_THEATER_SEL_PAGE`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_WRK_THEATER_SEL_PAGE`(IN `P_LOCATION1` INT UNSIGNED, IN `P_LOCATION2` INT UNSIGNED, IN `P_AFFILIATE_SEQ` INT UNSIGNED, IN `P_THEATER_NM` VARCHAR(50), IN `P_OPERATION` VARCHAR(1), IN `P_FUND_FREE` VARCHAR(1), IN `P_PAGENO` INT  UNSIGNED, IN `P_LISTCOUNT` INT UNSIGNED)
    COMMENT '극장정보 리스트를 페이지 단위로 구한다'
BEGIN

      SET @STARTROW  = (P_PAGENO - 1) * P_LISTCOUNT ;
      SET @LISTCOUNT = P_LISTCOUNT ;
      
      SET @WHERE_STR = "";
      
      IF  (P_LOCATION1 != '')     THEN SET @WHERE_STR = CONCAT(@WHERE_STR,"\n  AND TR.LOC1 = ",P_LOCATION1); END IF;
      IF  (P_LOCATION2 != '')     THEN SET @WHERE_STR = CONCAT(@WHERE_STR,"\n  AND TR.LOC2 = ",P_LOCATION2); END IF;
      IF  (P_AFFILIATE_SEQ != '') THEN SET @WHERE_STR = CONCAT(@WHERE_STR,"\n  AND TR.AFFILIATE_SEQ = ",P_AFFILIATE_SEQ); END IF;
      IF  (P_THEATER_NM != '')    THEN SET @WHERE_STR = CONCAT(@WHERE_STR,"\n  AND TR.THEATER_NM LIKE '",P_THEATER_NM,"%' "); END IF;
      IF  (P_OPERATION != '')     THEN SET @WHERE_STR = CONCAT(@WHERE_STR,"\n  AND TR.OPERATION = 'Y' "); END IF;
      IF  (P_FUND_FREE != '')     THEN SET @WHERE_STR = CONCAT(@WHERE_STR,"\n  AND TR.FUND_FREE = '",P_FUND_FREE,"' "); END IF;

      SET @xSql = CONCAT("   SELECT TR.CODE            
                                   ,LOC1.LOCATION_NM LOC1
                                   ,LOC2.LOCATION_NM LOC2
                                   ,AF.AFFILIATE_NM AFFILIATE_NM
                                   ,ID.DIRECT_NM
                                   ,UA.UNAFFILIATE_NM
                                   ,UG.USER_GROUP_NM
                                   ,TR.OPEN_DT         
                                   ,TR.OPERATION       
                                   ,TR.THEATER_NM      
                                   ,TR.ZIP             
                                   ,TR.ADDR1           
                                   ,TR.ADDR2           
                                   ,TR.SCORE_TEL       
                                   ,TR.SCORE_FAX       
                                   ,TR.SCORE_MAIL      
                                   ,TR.SCORE_SMS       
                                   ,TR.PREMIUM_TEL     
                                   ,TR.PREMIUM_FAX     
                                   ,TR.PREMIUM_MAIL    
                                   ,TR.PREMIUM_SMS     
                                   ,TR.FUND_FREE       
                                   ,TR.GUBUN_CODE      
                                   ,TR.SAUP_NO         
                                   ,TR.OWNER           
                                   ,TR.SANGHO          
                                   ,TR.HOMEPAGE        
                                   ,TR.IMAGES_NO       
                                   ,(
                                       SELECT COUNT(*) CNT_SHOWROOM
                                         FROM wrk_showroom
                                        WHERE TR.CODE = THEATER_CODE 
                                    ) AS CNT_SHOWROOM
                               FROM wrk_theater TR
                          LEFT JOIN bas_location LOC1   
                                 ON TR.LOC1 = LOC1.SEQ
                          LEFT JOIN bas_location LOC2   
                                 ON TR.LOC2 = LOC2.SEQ
                          LEFT JOIN bas_affiliate AF
                                 ON TR.AFFILIATE_SEQ = AF.SEQ
                          LEFT JOIN bas_isdirect ID
                                 ON TR.ISDIRECT = ID.CODE
                          LEFT JOIN bas_unaffiliate UA
                                 ON TR.UNAFFILIATE_SEQ = UA.SEQ
                          LEFT JOIN bas_user_group UG
                                 ON TR.UNAFFILIATE_SEQ = UG.SEQ
                              WHERE 1=1
                         ",           
                         @WHERE_STR,
                         "
                           ORDER BY TR.CODE
                              LIMIT ?,?     
                         ") ;
                         
                         
       PREPARE stmt FROM @xSql;
       
       EXECUTE stmt USING @STARTROW, @LISTCOUNT; 
       
       DEALLOCATE PREPARE stmt; ## prepare문을 해제한다.

          
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_WRK_THEATER_UNITPRICE_SAVE 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_WRK_THEATER_UNITPRICE_SAVE`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_WRK_THEATER_UNITPRICE_SAVE`(IN `P_THEATER_CODE` VARCHAR(6), IN `P_UNITPRICES` VARCHAR(200), IN `P_SEPAR` VARCHAR(1))
BEGIN

    DECLARE V_KEYWORD    VARCHAR(255);
    DECLARE V_TAGS_DONE TINYINT UNSIGNED;
    DECLARE V_TAGS_IDX INT UNSIGNED;    
    
    SET V_TAGS_DONE = 0;       
    SET V_TAGS_IDX = 1;
    
    DELETE FROM wrk_theater_unitprice
          WHERE THEATER_CODE = P_THEATER_CODE
                ;       
    
    WHILE NOT V_TAGS_DONE DO
        
        SET V_KEYWORD = SUBSTRING(P_UNITPRICES
                                 ,V_TAGS_IDX
                                 ,IF(LOCATE(P_SEPAR, P_UNITPRICES, V_TAGS_IDX) > 0, LOCATE(P_SEPAR, P_UNITPRICES, V_TAGS_IDX) - V_TAGS_IDX, LENGTH(P_UNITPRICES))      
                                 );
    
        IF LENGTH(V_KEYWORD) > 0 THEN
    
            SET V_TAGS_IDX = V_TAGS_IDX + LENGTH(V_KEYWORD) + 1;
            SET V_KEYWORD = TRIM(V_KEYWORD);
            
            INSERT INTO wrk_theater_unitprice
                      ( THEATER_CODE
                       ,UNIT_PRICE_SEQ
                      )
                 VALUES
                      (
                        P_THEATER_CODE 
                       ,V_KEYWORD
                      )
                      ;       

        ELSE
        
            SET V_TAGS_DONE = 1;
            
        END IF;
    
    END WHILE;       
   
END//
DELIMITER ;


-- 프로시저 my_test_db.SP_WRK_THEATER_UNITPRICE_SEL 구조 내보내기
DROP PROCEDURE IF EXISTS `SP_WRK_THEATER_UNITPRICE_SEL`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_WRK_THEATER_UNITPRICE_SEL`(IN `P_CODE` VARCHAR(6))
    COMMENT '한극장에 해당하는 요금단가를 구한다.'
BEGIN

call logwrite(P_CODE);

      SELECT UP.SEQ
            ,FORMAT(UP.UNIT_PRICE,0) UNIT_PRICE
            ,TU.UNIT_PRICE_SEQ ## NULL이면 해당극장의 요금이 아님
        FROM bas_unitprice UP
   LEFT JOIN ( SELECT * 
                 FROM wrk_theater_unitprice USE INDEX (primary)  
                WHERE THEATER_CODE = P_CODE COLLATE utf8_unicode_ci 
             ) TU
          ON UP.SEQ = TU.UNIT_PRICE_SEQ
    ORDER BY UP.UNIT_PRICE  
             ;
             
END//
DELIMITER ;


-- 함수 my_test_db.FN_NEXT_FILM 구조 내보내기
DROP FUNCTION IF EXISTS `FN_NEXT_FILM`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` FUNCTION `FN_NEXT_FILM`() RETURNS varchar(8) CHARSET utf8
    NO SQL
    COMMENT '영화 새 일련번호를 구한다.'
BEGIN

    DECLARE V_NEW_CODE VARCHAR(8);
    
       SELECT CONCAT('M',LPAD(RIGHT(IFNULL(MAX(CODE),'M00000000'), 7) + 1,7,0))
         INTO V_NEW_CODE
         FROM wrk_film
    USE INDEX (PRIMARY)
              ;

     RETURN V_NEW_CODE;
     
END//
DELIMITER ;


-- 함수 my_test_db.FN_NEXT_PLAY 구조 내보내기
DROP FUNCTION IF EXISTS `FN_NEXT_PLAY`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` FUNCTION `FN_NEXT_PLAY`() RETURNS decimal(10,0)
    NO SQL
    COMMENT '상영 새 일련번호를 구한다.'
BEGIN
    DECLARE VAL DECIMAL(10,0);
    
    UPDATE CFG_SEQUENCE
      SET PLAY = PLAY  +1;     
     
    SELECT PLAY INTO VAL
     FROM CFG_SEQUENCE ;
     
     RETURN VAL;
END//
DELIMITER ;


-- 함수 my_test_db.FN_NEXT_THEATER 구조 내보내기
DROP FUNCTION IF EXISTS `FN_NEXT_THEATER`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` FUNCTION `FN_NEXT_THEATER`() RETURNS varchar(6) CHARSET utf8
    NO SQL
    COMMENT '극장 새 일련번호를 구한다.'
BEGIN

    DECLARE V_NEW_CODE VARCHAR(6);
    
       SELECT CONCAT('TH',LPAD(RIGHT(IFNULL(MAX(CODE),'TH0000'), 4) + 1,4,0))
         INTO V_NEW_CODE
         FROM wrk_theater 
    USE INDEX (PRIMARY)
              ;

     RETURN V_NEW_CODE;
     
END//
DELIMITER ;


-- 함수 my_test_db.FN_SPLIT_STRING 구조 내보내기
DROP FUNCTION IF EXISTS `FN_SPLIT_STRING`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` FUNCTION `FN_SPLIT_STRING`(`x` text, `delim` varchar(32), `pos` int ) RETURNS text CHARSET utf8 COLLATE utf8_unicode_ci
    COMMENT 'SPLIT구현 함수'
RETURN SUBSTRING_INDEX(SUBSTRING_INDEX(x, delim, pos), delim, -1)//
DELIMITER ;


-- 이벤트 my_test_db.EV_LOG_CLEAR 구조 내보내기
DROP EVENT IF EXISTS `EV_LOG_CLEAR`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` EVENT `EV_LOG_CLEAR` ON SCHEDULE EVERY 1 MINUTE STARTS '2016-12-14 17:26:56' ON COMPLETION PRESERVE ENABLE COMMENT '로그를 매1분마다 지운다.' DO BEGIN

    CALL logwrite(CONCAT('1분단위 로그 삭제 ',NOW()));

    ## 1분전 자료는 일단 지운다.
    DELETE FROM tmp_log
    WHERE log_datetime <= DATE_SUB(NOW(),INTERVAL 1 MINUTE);
    
    
    ## 추가된 레코드의 갯수...
    SELECT COUNT(*) INTO @CNT_ROW 
      FROM tmp_log
           ;
           
    ## 하나면 일련번호를 0 으로 셋팅.
    IF  @CNT_ROW = 1 THEN
    
        UPDATE tmp_log
           SET SEQ = 0
               ; 
        
    END IF;       
    
END//
DELIMITER ;


-- 트리거 my_test_db.TRG_THEATER_INSERT 구조 내보내기
DROP TRIGGER IF EXISTS `TRG_THEATER_INSERT`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRG_THEATER_INSERT` AFTER INSERT ON `wrk_theater` FOR EACH ROW BEGIN
    DECLARE SEQ_NO NUMERIC;
    
    SELECT IFNULL(MAX(SEQ),0)+1 INTO SEQ_NO FROM wrk_theater_chghist ;

    INSERT INTO wrk_theater_chghist
                ( SEQ
                 ,GUBUN 
                 ,THEATER_CODE
                 ,CHANGE_DATE
                 ,CHANGE_TIME
                 ,LOC1
                )
         VALUES (
                  SEQ_NO
                 ,'INSERT' 
                 ,NEW.CODE
                 ,SYSDATE()
                 ,SYSDATE()
                 ,NEW.LOC1
                )  
                ;
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- 트리거 my_test_db.TRG_THEATER_UPDATE 구조 내보내기
DROP TRIGGER IF EXISTS `TRG_THEATER_UPDATE`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRG_THEATER_UPDATE` BEFORE UPDATE ON `wrk_theater` FOR EACH ROW BEGIN
    DECLARE SEQ_NO NUMERIC;
    
    SELECT IFNULL(MAX(SEQ),0)+1 INTO SEQ_NO FROM wrk_theater_chghist ;

    INSERT INTO wrk_theater_chghist
                ( SEQ
                 ,GUBUN 
                 ,THEATER_CODE
                 ,CHANGE_DATE
                 ,CHANGE_TIME
                 ,LOC1
                 ,LOC2
                 ,AFFILIATE_SEQ
                 ,ISDIRECT
                 ,UNAFFILIATE_SEQ
                 ,USER_GROUP_SEQ
                 ,OPERATION
                 ,THEATER_NM
                 ,FUND_FREE
                 ,GUBUN_CODE
                 ,SAUP_NO
                 ,OWNER
                 ,SANGHO
                 ,HOMEPAGE
                 ,IMAGES_NO
                )
         VALUES (
                  SEQ_NO
                 ,'UPDATE' 
                 ,OLD.CODE
                 ,SYSDATE()
                 ,SYSDATE()
                 ,OLD.LOC1
                 ,OLD.LOC2
                 ,OLD.AFFILIATE_SEQ
                 ,OLD.ISDIRECT
                 ,OLD.UNAFFILIATE_SEQ
                 ,OLD.USER_GROUP_SEQ
                 ,OLD.OPERATION
                 ,OLD.THEATER_NM
                 ,OLD.FUND_FREE
                 ,OLD.GUBUN_CODE
                 ,OLD.SAUP_NO
                 ,OLD.OWNER
                 ,OLD.SANGHO
                 ,OLD.HOMEPAGE
                 ,OLD.IMAGES_NO
                )  
                ;
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- 뷰 my_test_db.VW_BJD_LIST 구조 내보내기
DROP VIEW IF EXISTS `VW_BJD_LIST`;
-- 임시 테이블을 제거하고 최종 VIEW 구조를 생성
DROP TABLE IF EXISTS `VW_BJD_LIST`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` VIEW `VW_BJD_LIST` AS select 1 AS `DO_CODE`,1 AS `CITY_CODE`,1 AS `KU_CODE`,1 AS `DONG_CODE`,1 AS `LEE_CODE`,1 AS `BJD_NAME` ;


-- 뷰 my_test_db.VW_BJD_LIST_FULL 구조 내보내기
DROP VIEW IF EXISTS `VW_BJD_LIST_FULL`;
-- 임시 테이블을 제거하고 최종 VIEW 구조를 생성
DROP TABLE IF EXISTS `VW_BJD_LIST_FULL`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` VIEW `VW_BJD_LIST_FULL` AS select 1 AS `DO_CODE`,1 AS `CITY_CODE`,1 AS `KU_CODE`,1 AS `DONG_CODE`,1 AS `LEE_CODE`,1 AS `BJD_NAME`,1 AS `DO_NAME`,1 AS `CITY_NAME`,1 AS `KU_NAME`,1 AS `DONG_NAME`,1 AS `LEE_NAME` ;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
